/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */
package org.shemp.tools;

import org.shemp.common.*;

import sun.misc.BASE64Decoder;

import javax.security.auth.x500.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.security.cert.*;


/**
 * This is a simple utility used to construct SHEMP attribute certificates.
 */
public class ACBuilder
{
    /**
     * This method construct the header for the unsigned AC.  It
     * populates the subjectDN and issuerDN fields from the requestFile
     * and issuerCertFile respectively.
     *
     * @param subjCrtFile the path to the file holding the subject's X509 cert
     * @param issuerCrtFile the path to the file holding the issuers X509 cert
     * @param out the FileOutputStream to dump the header to
     * @return the issuer's DN as a String
     * @throws Exception if there is a problem reading the files
     */
    private static String buildHeader( String subjCrtFile, String issuerCrtFile,
				       FileOutputStream out ) throws Exception
    {
	String subjectDN = getDN( subjCrtFile );
	String issuerDN = getDN( issuerCrtFile );
	String header = 
	    "<attrcert>\n\n" +
	    "   <envelope>\n" +
	    "      <subjectDN>" + subjectDN + "</subjectDN>\n" +
	    "      <issuerDN>" + issuerDN + "</issuerDN>\n" +
	    "      <attributes>\n\n";

	out.write( header.getBytes() );

	return issuerDN;
    }


    /**
     * This method just pulls the subject out of a certificate and
     * returns it as a String.
     *
     * @param certFile the path to the file containing the certificate
     * @return the DN
     * @throws Exception if there is a problem loading the certificate
     */
    private static String getDN( String issuerCertFile ) throws Exception
    {
	String certStr = new String( FileUtil.readBytes(issuerCertFile) );
	X509Certificate cert = KeyUtil.getCertificate( certStr );
	X500Principal dn = cert.getSubjectX500Principal();

	return dn.getName();
    }


    /**
     * This method generates the attributes in the form:
     * <attribute>name=value</attribute>
     *
     * @param out the FileOutputStream to dump the policy to
     * @throws Exception if something goes wrong
     */
    private static void buildAttributes( FileOutputStream out )	throws Exception
    {
	String choice = "";
	BufferedReader b = 
	    new BufferedReader( new InputStreamReader(System.in) );

	while (true)
	{
	    String name = "";
	    String value = "";

	    System.out.print( "\nAdd an attribute to the cert? [y/n] => " );
	    choice = b.readLine();
	    
	    if (choice.compareToIgnoreCase( "y" ) == 0)
	    {
		System.out.print( "Name of the attribute to add => " );
		name = b.readLine();
		System.out.print( "The value of this attribute => " );
		value = b.readLine();

		String a =  "          <attribute>" + name + "=" +
		    value + "</attribute>\n";

		out.write( a.getBytes() );
	    }
	    else if (choice.compareToIgnoreCase( "n" ) == 0)
	    {
		break;
	    }
	    else ;

	    choice = "";
	}
    }


    /**
     * Builds a footer for the KUP and writes it to a file.
     *
     * @param out the FileOutputStream to dump the footer to.
     * @throws IOException is there is a problem writing to the file
     */
    private static void buildFooter( FileOutputStream out ) throws IOException
    {
	String footer =
	    "\n      </attributes>\n" +
	    "   </envelope>\n\n" +
	    "   <envelopeSignature></envelopeSignature>\n\n" +
	    "</attrcert>\n";

	out.write( footer.getBytes() );
    }


    /**
     * Command-line routine that bundles together all the information
     * needed to create an Attribute Certificate and then encodes the
     * certificate, printing to a file.
     */
    public static void main( String [] args )
    {
	if (args.length != 3)
	{
	    System.out.println( "Usage: java ACBuilder <subject_cert_file>" +
				" <issuer_cert_file> <output_file>" );
	    System.exit( 1 );
	}

	String subjectCertFile = args[0];
	String issuerCertFile = args[1];
	String outFile = args[2];

	try
	{
	    FileOutputStream out = new FileOutputStream( outFile );
	    buildHeader( subjectCertFile, issuerCertFile, out );
	    buildAttributes( out );
	    buildFooter( out );
	}
	catch( Exception e )
	{
	    e.printStackTrace();
	}
    }    
}
