/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.tools;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.interfaces.*;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;


/**
 * This utility extracts the public key from an X509Certificate,
 * puts into PEM format, and writes it the the keyfile.  SHEMP
 * repositories expect a PEM-encoded key, but keytool can't export
 * just keys---so, I'm rolling my own.
 */
public class ExtractKey
{
    public static void main( String args[] )
    {
	if (args.length != 2)
	{
	    System.err.println( "Usage: java ExtractKey <certfile> <keyfile>" );
	    System.exit( -1 );
	}

	try
	{
	    // Get the cert and key
	    CertificateFactory cf = CertificateFactory.getInstance( "X.509" );
	    FileInputStream fis = new FileInputStream( args[0] );
	    BufferedInputStream bis = new BufferedInputStream( fis );
	    X509Certificate cert = 
		(X509Certificate) cf.generateCertificate( bis );
	    RSAPublicKey pk = (RSAPublicKey) cert.getPublicKey();

	    // Get the key to Base64
	    BASE64Encoder b64e = new BASE64Encoder();
	    String b64key = b64e.encode( pk.getEncoded() );
	    String pemkey = "-----BEGIN PUBLIC KEY-----\n" + b64key +
		            "\n-----END PUBLIC KEY-----\n";

	    // Dump to file
	    PrintWriter out = new PrintWriter( new BufferedWriter(
						   new FileWriter(args[1])) );
	    out.write( pemkey );
	    out.flush();
	    out.close();
	}
	catch( Exception e )
	{
	    e.printStackTrace();
	}
    }
}
