/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import java.io.*;
import java.net.*;
import java.security.*;
import java.security.cert.*;

import javax.security.auth.x500.*;


/**
 * This class is used to get the XACML policy and populate a
 * RequestDataObj which holds the information.  The KupPopulator then
 * find the KUP, verifies the signature, and places the data into the
 * RequestDataObj.
 */
public class KupPopulator extends Populator
{
    private String _login;
    private String _dir;
    

    /**
     * The constuctor takes the static infomation, and the <code>popluate</code>
     * method does the rest.
     *
     * @param login the login of the user making the request
     * @param dir the location of all the certs
     */
    public KupPopulator( String login, String dir )
    {
	_login = login;
	_dir = dir;
    }

    
    /**
     * This is the hook that clients use to get the data and
     * put it in the RequestDataObj.  It goes through the directory,
     * looking for the KUP which applies to the current user.  Once the
     * RequestDataObj has been filled out, it is returned to the client.
     *
     * @return the XACML policy contained in the KUP
     */
    public String populate() throws Exception
    {
	String kupcert = _dir + "/" + _login + "attr.xml";

	AttributeCertHandler handler = new AttributeCertHandler( kupcert );

	boolean kupverified = verifyAttribute( handler.getEnvelopeAsStr(),
					       handler.getEnvelopeSigAsStr(),
					       _dir,
					       handler.getIssuerDN() );
	if (kupverified == true)
	{
	    String envelope = handler.getEnvelopeAsStr();
	    int begin = envelope.indexOf( "<XACML>" ) + "<XACML>".length();
	    int end = envelope.lastIndexOf( "</XACML>" );

	    return envelope.substring( begin, end );
	}

	return null;
    }
}
