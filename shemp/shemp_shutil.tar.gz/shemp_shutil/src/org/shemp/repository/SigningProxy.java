/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import com.sun.xacml.ctx.RequestCtx;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.interfaces.*;

import javax.crypto.*;
import javax.net.*;
import javax.net.ssl.*;

/**
 * This class is used to verify messages which were signed with a
 * user's temporary private key.  Once the verification succeeds, a
 * policy check occurs, and if successful, the message is signed with
 * with the user's long-term private key and returned to the user.
 */
public class SigningProxy
{
    private InputStream _in = null;
    private OutputStream _out = null;
    private SSLSession _session = null;


    /**
     * Sets up a new SigningProxy
     *
     * @param in the InputStream to the client
     * @param out the OutputStream to the client
     * @param session the SSLSession for this connection
     */
    public SigningProxy( InputStream in, OutputStream out, SSLSession session )
    {
	_in = in;
	_out = out;
	_session = session;
    }


    /**
     * The public method to sign.
     *
     * @param pkt the Packet object from the socket
     * @param login the username to mint a proxy cert for 
     */
    public void sign( Packet pkt, String login ) throws Exception
    {
	String pempc = pkt.getPayload();

        // Do the policy check
	PolicyEngine pe = new PolicyEngine( login, _session );
	RequestCtx request = pe.generateRequest( "sign" );
	boolean allowed = pe.isAllowed( request );

	if (allowed == false)
	{
	    Packet reply = new Packet( "RSIGN", "POLICY_FAIL" );
	    PacketComm.send( reply, _out );
	}
	else
	{
	    // Send a continue to get the message
	    Packet cont = new Packet( "RSIGN", "CONTINUE" );
	    PacketComm.send( cont, _out );

	    Packet msgpkt = PacketComm.recv( _in );
	    String msg = msgpkt.getPayload();
	    msgpkt.dump();

	    PacketComm.send( cont, _out );

	    Packet sigpkt = PacketComm.recv( _in );
	    String sig = sigpkt.getPayload();
	    sigpkt.dump();

	    if (verify( msg, sig, pempc ) == true)
	    {
		String sig64 = sign( msg, login );
		Packet reply = new Packet( "RSIGN", sig64 );
		PacketComm.send( reply, _out );
	    }
	    else
	    {
		Packet errpkt = new Packet( "RSIGN", "Verification failed." );
		PacketComm.send( errpkt, _out );
	    }
	}
    }


    /**
     * This method is used to verify a message.  Ideally the msg
     * has been signed with the user's short-term key.
     */
    private boolean verify( String msg, String sig, String crt )
	throws Exception
    {
	BASE64Decoder b64d = new BASE64Decoder();
	byte [] msgbytes = b64d.decodeBuffer( msg );
	byte [] sigbytes = b64d.decodeBuffer( sig );

	crt = KeyUtil.prettyPrintCerts( crt );
	X509Certificate pc = KeyUtil.getCertificate( crt );

	Signature s = Signature.getInstance( "SHA1withRSA" );
	s.initVerify( pc );
	s.update( msgbytes );

	return s.verify( sigbytes );
    }


    /**
     * This method is used to sign a message with the alias's private
     * key which should reside in the repostitory's keystore.  It returns
     * the signature as a Base64 encoded String.
     */
    private String sign( String msg, String alias ) throws Exception
    {
	// Decode the message
	BASE64Decoder b64d = new BASE64Decoder();
	byte [] msgbytes = b64d.decodeBuffer( msg );

	// Load the keystore
	String pw = ConfigOptions.instance().getUserPword();
	KeyStore ks = KeyUtil.loadKeystore( 
	    ConfigOptions.instance().getUserstore(), pw );
	
	// Get the key
	KeyStore.PasswordProtection pp = 
	    new KeyStore.PasswordProtection( pw.toCharArray() );
	KeyStore.PrivateKeyEntry pke = 
	    (KeyStore.PrivateKeyEntry) ks.getEntry( alias, pp );

	PrivateKey privkey = pke.getPrivateKey();

	// Sign the message
	Signature s = Signature.getInstance( "SHA1withRSA" );
	s.initSign( privkey );
	s.update( msgbytes );
	byte [] sig = s.sign();

	// Encode the result
	BASE64Encoder b64 = new BASE64Encoder();
	return b64.encode( sig );
    }
}
