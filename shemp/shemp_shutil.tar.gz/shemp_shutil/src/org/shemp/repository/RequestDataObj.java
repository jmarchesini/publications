/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import java.io.*;
import java.net.*;
import java.util.*;

import com.sun.xacml.*;
import com.sun.xacml.attr.*;
import com.sun.xacml.ctx.*;
import javax.security.auth.x500.X500Principal;


/**
 * This class holds the data which will be used in the request.
 * The data is maintained in four HashSets for each of the Attributes:
 * Subject, Action, Resource, and Environment.
 */
public class RequestDataObj
{
    private HashSet _subject;
    private HashSet _resource;
    private HashSet _action;
    private HashSet _environment;


    public RequestDataObj()
    {
	_subject = new HashSet();
	_resource = new HashSet();
	_action = new HashSet();
	_environment = new HashSet();
    }


    /**
     * Sets up the Subject section of the request. This Request only has
     * one Subject section, and it uses the default category. To create a
     * Subject with a different category, you simply specify the category
     * when you construct the Subject object.
     *
     * @param subject the String representing the subject
     * @throws URISyntaxException if there is a problem with a URI
     */
    public void addSubject( String subject ) throws URISyntaxException
    {
	HashSet attributes = new HashSet();

        URI subjectId = 
	    new URI( "urn:oasis:names:tc:xacml:1.0:subject:subject-id" );

        X500NameAttribute value =
            new X500NameAttribute( new X500Principal(subject) );

        attributes.add( new Attribute(subjectId, null, null, value) );

        _subject.add( new Subject(attributes) );
    }


    /**
     * Creates a Resource specifying the resource-id, a required attribute.
     *
     * @param resource the String "Private Key" is all SHEMP uses.
     * @throws URISyntaxException if there is a problem with a URI
     */
    public void addResource( String resource ) throws URISyntaxException
    {
        StringAttribute value = new StringAttribute( resource );
        _resource.add( new Attribute( new URI(EvaluationCtx.RESOURCE_ID),
				      null, null, value) );
    }


    /**
     * Creates an Action specifying the action-id, an optional attribute.
     *
     * @param action the action to perform in {generate, decrypt, sign}
     *
     * @throws URISyntaxException if there is a problem with a URI
     */
    public void addAction( String action ) throws URISyntaxException
    {
        URI actionId =
            new URI( "urn:oasis:names:tc:xacml:1.0:action:action-id" );

        _action.add( new Attribute(actionId, null, null, 
				   new StringAttribute(action)) );
    }


    /**
     * Creates an Environment which will be the concatenation of the
     * repository environment and the platform environment.
     *
     * @param key is the name of the attribute, e.g., SecureAgainstNetworkAttack
     * @param value is the value of the attribute, e.g., true
     * @param issuer is the issuing party, e.g., Platform Administrator
     * @throws URISyntaxException if there is a problem with a URI
     */
    public void addEnvironment( String key, String value, String issuer )
	throws URISyntaxException
    {
	Attribute attr = new Attribute( new URI(key), issuer, null, 
					new StringAttribute(value) );
	_environment.add( attr );
    }


    /**
     * Returns the HashSet holding the subject attributes.
     *
     * @return the HashSet holding the subject attributes
     */ 
    public HashSet getSubject()
    {
	return _subject;
    }

    
    /**
     * Returns the HashSet holding the resource attributes.
     *
     * @return the HashSet holding the resource attributes
     */
    public HashSet getResource()
    {
	return _resource;
    }


    /**
     * Returns the HashSet holding the action attributes.
     *
     * @return the HashSet holding the action attributes
     */
    public HashSet getAction()
    {
	return _action;
    }


    /**
     * Returns the HashSet holding the environment attributes.
     *
     * @return the HashSet holding the environment attributes
     */
    public HashSet getEnvironment()
    {
	return _environment;
    }
}
