/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shapi;

import sun.misc.BASE64Encoder;

import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;

import javax.net.*;
import javax.net.ssl.*;

import org.shemp.common.*;


/**
 * This is the interface clients use to communicate with a SHEMP 
 * repository.
 */
public class Shapi
{
    private InputStream _in = null;
    private OutputStream _out = null;

    private String _keystore;
    private String _password;

    private SSLSocket _sock = null;
    private SSLSocketFactory _factory = null;

    private boolean _authenticated;


    /**
     * Sets up a new Shapi object.  Clients use the connect method to
     * establish a connection to the repository.
     *
     * @param keystore the file where the local JKS keystore resides
     * @param pass the password for the keystore
     */
    public Shapi( String keystore, String pass )
    {
	_authenticated = false;
	_keystore = keystore;
	_password = pass;
    }


    /**
     * This method is used to connect to a repository.
     *
     * @param host the machine where the repository software is located
     * @param port the port where the repository software is listening
     */
    public void connect( String host, int port ) throws Exception
    {
	SSLContext ctx = KeyUtil.getSSLContext( _keystore, _password );

	_factory = ctx.getSocketFactory();	    
	_sock = (SSLSocket)_factory.createSocket( host, port );	    
	_sock.startHandshake();
	_out = _sock.getOutputStream();
	_in = _sock.getInputStream();
    }


    /**
     * This method is used to get a challenge string from the repository.
     *
     * @return the challenge String
     */
    public String getAuthChallenge() throws IOException
    {
	Packet pkt = new Packet( "UAUTH", "AUTHENTICATE" );
	PacketComm.send( pkt, _out );

	Packet rec = PacketComm.recv( _in );
	return rec.getPayload();
    }


    /**
     * This is used to send authentication replies back to the repository
     *
     * @param reply the reply to send
     */
    public void sendAuthReply( String reply ) throws IOException
    {
	Packet pkt = new Packet( "UAUTH", reply );
	PacketComm.send( pkt, _out );

	Packet rec = PacketComm.recv( _in );
	String payload = rec.getPayload();

	if ("AUTHENTICATED".compareToIgnoreCase( payload ) == 0)
	{
	    _authenticated = true;
	}
    }


    /**
     * This is used to send a pulic key (PEM format) to the repository,
     * and get a Proxy Cert containing that key in return.
     *
     * @param pubkey the public portion of the temporary keypair
     * @return the Base 64 and DER-encoded Proxy Certificate 
     * @throws Exception if the network has problems
     */
    public String getProxyCert( String pubkey ) throws Exception
    {
	Packet pkt = new Packet( "PCREQ", pubkey );
	PacketComm.send( pkt, _out );

	Packet rec = PacketComm.recv( _in );
	String pc = rec.getPayload();

	return pc;
    }


    /**
     * This is used to send a message to the repository which has
     * been encrypted with the user's long-term public key.  The
     * repository will unencrypt it, and the re-encrypt it with the
     * public key in the Proxy Cert.
     *
     * @param ciphertext the message encrypted with the user's long-term key
     * @param pc the user's current proxy certificate
     * @return the message encrypted with the user's PC public key
     * @throws Exception if the network has problems
     */
    public String encrypt( String ciphertext, String pc ) throws Exception
    {
	Packet pcpkt = new Packet( "ECRPT", pc );
	PacketComm.send( pcpkt, _out );

	// Block and wait for continue/policy_fail message.
	Packet rec = PacketComm.recv( _in );
	String msg = rec.getPayload();

	if (msg.compareToIgnoreCase("POLICY_FAIL") == 0)
	{
	    return msg;
	}

	Packet msgpkt = new Packet( "ECRPT", ciphertext );
	PacketComm.send( msgpkt, _out );

	Packet respkt = PacketComm.recv( _in );
	return respkt.getPayload();
    }


    /**
     * This is used to send a message to the repository which has
     * been signed with a user's temporary private key (i.e., the private
     * portion of the key decribed in the Proxy Certificate).  The
     * repository will first verify the message with the public key in
     * the PC.  If successful, a policy check will occur.  If the policy
     * allows the operation, the repository will then sign the message
     * with the user's long-term private key.
     *
     * @param msg the message to sign
     * @param sig the message signed with the user's temp private key
     * @param crt the user's proxy certificate in a PEM formatted String
     * @return the msg signed with the user's long-term private key (Base64) 
     * @throws Exception if the network has problems
     */
    public String sign( byte [] msg, byte [] sig, String crt ) throws Exception
    {
	BASE64Encoder b64e = new BASE64Encoder();
	String msg64 = b64e.encode( msg );
	String sig64 = b64e.encode( sig );

	// Send the cert
	Packet crtpkt = new Packet( "RSIGN", crt );
	PacketComm.send( crtpkt, _out );

	// Block and wait for continue message.
	Packet reppkt = PacketComm.recv( _in );
	String rep = reppkt.getPayload();

	if (rep.compareToIgnoreCase("POLICY_FAIL") == 0)
	{
	    return rep;
	}

	// Send the msg
	Packet msgpkt = new Packet( "RSIGN", msg64 );
	PacketComm.send( msgpkt, _out );

	// Block and wait for continue message.
	reppkt = PacketComm.recv( _in );

	// Send the sig
	Packet sigpkt = new Packet( "RSIGN", sig64 );
	PacketComm.send( sigpkt, _out );

	// Block and wait for result.
	Packet respkt = PacketComm.recv( _in );
	return respkt.getPayload();
    }


    /**
     * This is used to send a LOGOF message to the repository, close
     * the streams, and then close the socket.
     *
     * @throws IOException if the streams or socket won't close
     */
    public void logoff() throws IOException
    {
	Packet lo = new Packet( "LOGOF", "Logoff reqst" );
	PacketComm.send( lo, _out );

	_in.close();
	_out.close();
	_sock.close();

	_authenticated = false;
    }


    /**
     * Tells whether this Shapi can be used to perform repository
     * operations on behalf of a user.
     *
     * @return whether the Shapi object is authenticated
     */
    public boolean authenticated()
    {
	return _authenticated;
    }
}
