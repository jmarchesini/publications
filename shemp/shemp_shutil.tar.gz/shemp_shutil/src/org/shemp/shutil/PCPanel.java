/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;
import org.shemp.common.*;

import javax.swing.*;          
import java.awt.*;
import java.awt.event.*;


/**
 * This is the class that handles the Proxy Certificate tab which is used
 * to generate Proxy Certs
 */
public class PCPanel extends JPanel
{   
    private JTextArea _console;
    private JButton _sendButton;
    private Shapi _api;


    /**
     * This is the handler for the Generate button.  It generates
     * a Proxy Certificate.
     */
    public class Generate implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    try
	    {
		String utildir = ConfigOptions.instance().getUtilDir();
		String keyfile = utildir + "/tempkey.pem";

		_console.append( "Calling createTempKey.sh to " +
				 "create a temporary keypair and get a PC.\n" );

		Runtime rt = Runtime.getRuntime();
		Process p = rt.exec( utildir + "/createTempKey.sh" );
		p.waitFor();

		String pubkey = FileUtil.read( keyfile );
		String cert = _api.getProxyCert( pubkey );
	
		if (cert.compareToIgnoreCase("POLICY_FAIL") == 0)
		{
		    _console.append( "\nThe generation request was denied " +
				     "due to the user's policy and current " +
				     "environment.\nNo new PC was generated." );
		}
		else
		{
		    String crtfile = utildir + "/tempkey.cer";
		    _console.append( "The following PC was was written to: " + 
				     crtfile + ":\n\n" );
		    FileUtil.write( crtfile, cert );
		    _console.append( cert );
		}
	    }	
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}
    }


    /**
     * This handler is used to destroy PCs.
     */
    public class Destroy implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    try
	    {
		_console.append( "\nCalling destroyTempKey.sh to clean up.\n" );
		String utildir =  ConfigOptions.instance().getUtilDir();

		Runtime rt = Runtime.getRuntime();
		Process p = rt.exec( utildir + "/destroyTempKey.sh" );
		p.waitFor();
	    }
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}
    }


    /**
     * This builds the Generate tab, and registers all of the handlers.
     *
     * @param api the Shapi object
     */
    public PCPanel( Shapi api )
    {
        super( new BorderLayout() );

	// Create the console area
	JPanel consolePane = new JPanel();
	consolePane.setLayout( new BorderLayout() );

	_console = new JTextArea( 
	    "To generate a temporary keypair and Proxy Certificate, press " +
	    " the Generate PC button.\nTo destroy a temporary keypair and " +
	    "Proxy Certificate, press the Destroy PC button.\n\n" );
        _console.setLineWrap( false );
        _console.setWrapStyleWord( false );
	_console.setEditable( false );

        JScrollPane areaScrollPane = new JScrollPane( _console );	
        areaScrollPane.setVerticalScrollBarPolicy(
	    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
	areaScrollPane.setHorizontalScrollBarPolicy(
	    JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS );
        areaScrollPane.setPreferredSize( new Dimension(190, 190) );

	consolePane.add( areaScrollPane, BorderLayout.CENTER );
        consolePane.setBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Proxy Certificate"),
            BorderFactory.createEmptyBorder(5,5,5,5)),
	    consolePane.getBorder() ));
       
	//Lay out the buttons
        JPanel buttonPane = new JPanel();
	buttonPane.setLayout( new GridLayout(1, 2) );
	buttonPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder( "" ),
	    BorderFactory.createEmptyBorder(17,10,17,10) ));

	JButton generate = new JButton( "Generate PC" );
        generate.setMnemonic( KeyEvent.VK_G );
        generate.addActionListener( new Generate() );
	buttonPane.add( generate );

	JButton destroy = new JButton( "Destroy PC" );
        destroy.setMnemonic( KeyEvent.VK_D );
        destroy.addActionListener( new Destroy() );
	buttonPane.add( destroy );

	add( consolePane, BorderLayout.CENTER );
	add( buttonPane, BorderLayout.PAGE_END );

	_api = api;
    }
}

