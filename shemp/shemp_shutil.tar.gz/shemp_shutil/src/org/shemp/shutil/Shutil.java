/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;
import org.shemp.common.*;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.*;
import java.util.*;


/**
 * This is a demo application that shows how to use the SHEMP API
 * (Shapi) to work with a SHEMP repository.  It is just a command-line
 * tool used to exercise all of the SHEMP operations: generate a PC,
 * use the encryption proxy service, and use the signing proxy service.
 */
public class Shutil
{
    static private boolean TIMING = false;


    /**
     * USAGE: java Shutil <conffile> [true] where [true] is an
     * optional parameter to activate timing.
     */
    static public void main( String args[] )
    {
	String conffile = "";
	String choice = "";

	if (args.length < 1)
	{
	    System.out.println( "USAGE: java Shutil <conffile> [true]\n" +
		                "       (where [true] is an optional " +
                                "parameter to activate timing)" );
	    System.exit( -1 );
	}
	else 
	{
	    conffile = args[0];
	}

	if (args.length == 2 && args[1].compareToIgnoreCase("true") == 0)
	{
	    TIMING = true;
	}

	// Parse Config File and populate ConfigOptions
	ConfigOptions co = ConfigOptions.instance();

	try
	{
	    ConfFileHandler handler = new ConfFileHandler( conffile );
	    SaxParserDriver parser = 
		new SaxParserDriver( handler.getFileAsStr(), handler );
	}
	catch( Exception e )
	{
	    System.err.println( "Unable to parse configuration file." );
	    System.exit( -1 );
	}

	Shapi api = new Shapi( co.getKeystore(), co.getPassword() );
	BufferedReader b = new BufferedReader(new InputStreamReader(System.in));

	try
	{
	    System.out.println( "\n\n==============================" );
	    System.out.println( "* Welcome to the SHUTIL v0.1 *" );
	    System.out.println( "==============================" );

	    platformAuth( b, api );
	    userAuth( b, api );

	    while (true)
	    {
		System.out.println( "\n\n---> Would you like to:\n" );
		System.out.println( "G)enerate a new Proxy Certificate" );
		System.out.println( "D)ecrypt a message which was encrypted " +
				    "with your long-term " );
		System.out.println( "  public key, and then encrypt it with " +
				    "your PC's public key." );
		System.out.println( "V)erify a message signed with your " +
				    "temporary private key," );
		System.out.println( "  and then sign it with your long-term " +
				    "private key." );
		System.out.println( "L)ogoff the repository and quit" );
		System.out.print( "\n[g/d/v/l] => " );

		choice = b.readLine();

		if (choice.compareToIgnoreCase("g") == 0)
		{
		    getPC( api );
		}
		else if (choice.compareToIgnoreCase("d") == 0)
		{
		    encryptProxy( b, api );
		}
		else if (choice.compareToIgnoreCase("v") == 0)
		{
		    signProxy( b, api );
		}
		else if (choice.compareToIgnoreCase("l") == 0)
		{
		    logoff( api );
		    System.exit( 0 );
		}
		else ;

		choice = "";
	    }
	}
	catch( Exception e )
	{
	    e.printStackTrace();
	}
    }


    /**
     * Platform Authentication is done via the magic of client-side SSL.
     *
     * @param b a BufferedReader reading from STDIN
     * @param api a Shapi object used to connect to the repository
     * @throws Exception if bad stuff happens
     */
    static private void platformAuth( BufferedReader b, Shapi api )
	throws Exception
    {
	System.out.println( "\n\n---> Performing Platform Authentication" );
	System.out.print( "Host where the repository is located: " );
	String host = b.readLine();

	System.out.print( "Port where the repository is running: " );
	int port = Integer.parseInt( b.readLine() );

	api.connect( host, port );
    }


    /**
     * User Authentication done via login/password.
     *
     * @param b a BufferedReader reading from STDIN
     * @param api a Shapi object used to connect to the repository
     * @throws Exception if bad stuff happens
     */
    static private void userAuth( BufferedReader b, Shapi api )
	throws Exception
    {
	System.out.println( "\n\n---> Performing User Authentication" );
	
	while (api.authenticated() == false)
	{
	    System.out.print( api.getAuthChallenge() );
	    String reply = b.readLine();
	    api.sendAuthReply( reply );
	}

	System.out.println( "Authenticated." );
    }


    /**
     * This method is used to contact the repository and get a PC.
     *
     * @param api a Shapi object used to connect to the repository
     * @throws Exception if bad stuff happens
     */
    static private void getPC( Shapi api ) throws Exception
    {
	String utildir =  ConfigOptions.instance().getUtilDir();
	String keyfile = utildir + "/tempkey.pem";

	System.out.println( "\n\n---> Calling createTempKey.sh to " +
			    "create a temporary keypair and get a PC" );

	// Start timer
	long start = System.currentTimeMillis();

	Runtime rt = Runtime.getRuntime();
	Process p = rt.exec( utildir + "/createTempKey.sh" );
	p.waitFor();

        // End timer1
	long genTime = System.currentTimeMillis() - start;

	String pubkey = FileUtil.read( keyfile );
	String cert = api.getProxyCert( pubkey );

        // End timer2
	long signTime = System.currentTimeMillis() - start;
	
	if (cert.compareToIgnoreCase("POLICY_FAIL") == 0)
	{
	    System.out.println( "\nThe generation request was denied due to " +
				"the user's policy and current environment." );
	    System.out.println( "No new PC was generated." );
	}
	else
	{
	    String crtfile = utildir + "/tempkey.cer";
	    System.out.println( "The PC was was written to " + crtfile );
	    FileUtil.write( crtfile, cert );
	}

	if (TIMING)
	{
	    System.out.println( "Time to generate key: " + genTime + " ms." );
	    System.out.println( "Time to generate cert: " + signTime + " ms." );
	}
    }


    /**
     * This function gracefully logs off of the repository.
     *
     * @param api a Shapi object used to connect to the repository
     * @throws Exception if bad stuff happens
     */
    static private void logoff( Shapi api ) throws Exception
    {
	String utildir =  ConfigOptions.instance().getUtilDir();

	System.out.println( "\n\n---> Logging off the repository" );
	api.logoff();

    	System.out.println( "---> Calling destroyTempKey.sh to clean up" );
	Runtime rt = Runtime.getRuntime();
	Process p = rt.exec( utildir + "/destroyTempKey.sh" );
	p.waitFor();
    }


    /**
     * This function sends an encrypted message and a PC to the repository.
     * The repository decrypts the message with the user's long term priv.
     * key, re-encrypts it with the pub. key in the PC, and returns it.
     *
     * @param b a BufferedReader reading from STDIN
     * @param api a Shapi object used to connect to the repository
     * @throws Exception if bad stuff happens
     */
    static private void encryptProxy( BufferedReader b, Shapi api )
	throws Exception
    {
	String utildir =  ConfigOptions.instance().getUtilDir();

	System.out.println( "\n\n---> Calling the en/decryption proxy" );
	System.out.print( "File that contains the encrypted message: " );
	String cipherfile = b.readLine();

	// Start timer
	long start = System.currentTimeMillis();

	String ciphertext = FileUtil.read( cipherfile );
	String crtfile = utildir + "/tempkey.cer";
	String proxycert = FileUtil.read( crtfile );
	String result = api.encrypt( ciphertext, proxycert );

        // End timer
	long time = System.currentTimeMillis() - start;
	
	if (result.compareToIgnoreCase("POLICY_FAIL") == 0)
	{
	    System.out.println( "\nThe decryption request was denied due to " +
				"the user's policy and current environment." );
	    System.out.println( "The message was not decrypted." );
	}
	else
	{
	    System.out.print( "File to dump ciphertext (encrypted with PC): " );
	    String resultfile = b.readLine();

	    FileUtil.write( resultfile, result );
	}
	
	if (TIMING)
	{
	    System.out.println( "Elapsed time: " + time + " ms." );
	}
    }


    /**
     * This function sends a PC, a message, and a signed SHA-1 of the
     * message to the repository (signed with the private key descibed by
     * the PC).  The repostitory verifies the signature with the PC, does
     * a policy check, and if allowed, signs the message with the user's
     * long-key private key.
     *
     * @param b a BufferedReader reading from STDIN
     * @param api a Shapi object used to connect to the repository
     * @throws Exception if bad stuff happens
     */
    static private void signProxy( BufferedReader b, Shapi api )
	throws Exception
    {
	String utildir =  ConfigOptions.instance().getUtilDir();

	System.out.println( "\n\n---> Calling signing proxy service" );
	System.out.print( "File that contains the message text: " );
	String msgfile = b.readLine();

	System.out.print( "File that contains the signed message " +
			  "(signed with your temp key): ");
	String sigfile = b.readLine();

	// Start timer
	long start = System.currentTimeMillis();

	String crtfile = utildir + "/tempkey.cer";
	String cert = FileUtil.read( crtfile );
	byte [] msg = FileUtil.readBytes( msgfile );
	byte [] sig = FileUtil.readBytes( sigfile );
	String newsig = api.sign( msg, sig, cert );

	// End timer
	long time = System.currentTimeMillis() - start;

	if (newsig.compareToIgnoreCase("POLICY_FAIL") == 0)
	{
	    System.out.println( "\nThe signing request was denied due to " +
				"the user's policy and current environment." );
	    System.out.println( "The message was not signed." );
	}
	else
	{
	    System.out.print( "File to dump new signature " +
			      "(signed with your long-term key): " );
	    String resultfile = b.readLine();

	    BASE64Decoder b64d = new BASE64Decoder();
	    FileUtil.writeBytes( resultfile, b64d.decodeBuffer(newsig) ); 
	}

	if (TIMING)
	{
	    System.out.println( "Elapsed time: " + time + " ms." );
	}
    }
}
