/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Puts the arguments from the conf file into the private members
 * of this class.
 */
public class ConfigOptions
{
    static private ConfigOptions _instance = null;

    private String _password;
    private String _keystore;
    private String _utildir;

    /**
     * Use the instance() method to construct.  
     */
    protected ConfigOptions()
    {
	_password = "";
	_keystore = "";
	_utildir = "";
    }


    /**
     * Callers use this method to aquire an instance of a
     * ConfigOptions object.
     *
     * @return a valid ConfigOptions instance
     */
    public synchronized static ConfigOptions instance()
    {
	if (_instance == null)
	{
	    _instance = new ConfigOptions();
	}

	return _instance;
    }


    /**
     * Sets the location of the keystore.
     *
     * @param str the path to the keystore
     */
    public void setKeystore( String str )
    {
	// The += feels wrong, but the DefaultParser only fetches 64 bytes
	// at a time.  So, on the boundary, this element gets called twice.

	_keystore += str;
    }
  

    /**
     * Sets the password for the keystore
     *
     * @param str the password
     */
    public void setPassword( String str )
    {
	_password = str;
    }


   /**
     * Sets the path to the utility directory
     *
     * @param str the path to the utility directory
     */
    public void setUtilDir( String str )
    {
	_utildir = str;
    }
   

    /**
     * Gets the password for the keystore
     *
     * @return the password
     */
    public String getPassword()
    {
	return _password;
    }


    /**
     * Gets the location of the keystore.
     *
     * @return the path to the keystore
     */    
    public String getKeystore()
    {
	return _keystore;
    }


    /**
     * Gets the path to the utility directory
     *
     * @return the path
     */
    public String getUtilDir()
    {
	return _utildir;
    }


    /**
     * Used for debugging only.
     */
    public void dumpConfig()
    {
	System.out.println( "DumpConfig" );
	System.out.println( "Keystore: " + _keystore );
	System.out.println( "Password: " + _password );
	System.out.println( "Utility Directory: " + _utildir );
    }
}

