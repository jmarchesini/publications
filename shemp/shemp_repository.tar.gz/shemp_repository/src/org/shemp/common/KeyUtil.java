/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.common;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.net.*;
import javax.net.ssl.*;
import javax.security.auth.x500.*;


/**
 * Utility class for dealing with certificates, keystores, and some
 * crypto functionality.
 */
public class KeyUtil
{ 
    /**
     * Opens up the keystore and gets a context.
     *
     * @param keystore the keystore to use
     * @param password the password for the keystore
     * @return the SSLContext to use
     */
    public static SSLContext getSSLContext( String keystore, String password )
	throws Exception
    {
	SSLContext ctx;
	TrustManagerFactory tmf;
	KeyManagerFactory kmf;
	KeyStore ks;

	char[] passphrase = password.toCharArray();

	ctx = SSLContext.getInstance( "TLS" );
	kmf = KeyManagerFactory.getInstance( "SunX509" );
	ks = KeyStore.getInstance( "JKS" );
	tmf = TrustManagerFactory.getInstance( "SunX509" );

	ks.load( new FileInputStream(keystore), passphrase );
	kmf.init( ks, passphrase );
	tmf.init( ks );	
	ctx.init( kmf.getKeyManagers(), tmf.getTrustManagers(), null );

	return ctx;
    }


    /**
     * This method loads a JKS keystore and returns the KeyStore object
     *
     * @param file the path to the keystore
     * @param pass the keystore password
     * @return the in-memory KeyStore
     * @throws Exception if the keystore isn't found, wrong type, etc.
     */
    static public KeyStore loadKeystore( String file, String pass )
	throws Exception
    {
	KeyStore kstore = KeyStore.getInstance( "JKS" );
	kstore.load( new FileInputStream(file), pass.toCharArray() );

	return kstore;
    }


    /**
     * This helper takes a Base64 encoded X509 cert, and returns an
     * X509Certificate java object.
     *
     * @param cert a String reprentation of a Base64 X509 certificate
     * @return the X509Certificate represented by cert
     * @throws CertificateException if the cert type isn't X509
     */
    static public X509Certificate getCertificate( String cert )
	throws CertificateException
    {
	CertificateFactory cf = CertificateFactory.getInstance( "X.509" );
	ByteArrayInputStream bais = new ByteArrayInputStream( cert.getBytes() );

	return (X509Certificate) cf.generateCertificate( bais );
    }


    /**
     * This helper fixes a certificate after it's newlines have been stripped,
     * e.g., if it has been sent over the wire.
     *
     * @param cert the PEM cert to fix in String format
     * @return the fixed certificate
     */
    static public String prettyPrintCerts( String cert )
    {
	cert = cert.replaceAll( "-----BEGIN CERTIFICATE-----", 
				"-----BEGIN CERTIFICATE-----\n" );
	cert = cert.replaceAll( "-----END CERTIFICATE-----", 
				"\n-----END CERTIFICATE-----\n" );
	return cert;
    }


    /**
     * This helper gets a CN from a DN.
     *
     * @param dn the DN to extract from
     * @return the CN as a String
     */
    static public String getCN( String dn )
    {
	// Extract the CN and Get the cert
	int begin = dn.indexOf( "CN=" ) + 3;
	int end = dn.indexOf( "," );
	
	return dn.substring( begin, end );
    }


    /**
     * Debugging function (or verbose logging function) to dump certificates.
     *
     * @param pc the Proxy Certificate (or any X59 cert, really) 
     */
    static public void dumpPC( X509Certificate pc )
    {
	System.out.println( "\n============================================" );

	X500Principal issuer = pc.getIssuerX500Principal();
	X500Principal subject = pc.getSubjectX500Principal();

	System.out.println( "Issuer     : " + issuer.getName() );
	System.out.println( "Subject    : " + subject.getName() );
	System.out.println( "Not Before : " + (pc.getNotBefore()).toString() );
	System.out.println( "Not After  : " + (pc.getNotAfter()).toString() );
	System.out.println( "Serial Num : " + pc.getSerialNumber() );
	System.out.println( "Sig. Alg.  : " + pc.getSigAlgName() );
	System.out.println( "Cert. Type : " + pc.getType() );

	RSAPublicKey pk = (RSAPublicKey) pc.getPublicKey();

	System.out.println( "Exponent   : " + pk.getPublicExponent() );
	System.out.println( "============================================" );
    }
}
