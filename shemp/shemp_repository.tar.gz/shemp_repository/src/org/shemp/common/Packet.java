/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.common;

import java.io.*;
import java.util.*;


/**
 * Packet for communication.
 */
public class Packet
{   
    private String _payload = null;
    private Header _header = null;


    /**
     * This is used to construct Packets from scratch.
     * The type should be in {UAUTH, PCREQ, ECRPT, RSIGN, LOGOF}.
     *
     * @param type a String which indicates the type of the packet
     * @param payload the packet payload in String format
     */
    public Packet( String type, String payload )
    {
	_header = new Header( type.toUpperCase() );
	_payload = payload;
	_header.setSize( _payload.length() );
    }


    /**
     * This is used to construct a packet from raw bytes (e.g.,
     * a socket read).
     *
     * @param header a pre-constructed header
     * @param buf a byte buffer containing a Packet
     */
    public Packet( Header header, byte[] buf )
    {
	_header = header;
	_payload = new String( buf );
    }


    /**
     * Encodes and makes a byte buffer out of the packet.
     *
     * @return a byte array containing the packet
     */
    public byte[] getBytes()
    {
	String result = _header.getDelimitedString() + _payload;

	return result.getBytes();
    }


    /**
     * Gets the packet's type.
     *
     * @return the type
     */
    public String getType()
    {
	return _header.getType();
    }


    /**
     * Get's the payload's size.
     *
     * @return the payload's size.
     */
    public int getSize()
    {
	return _header.getSize();
    }


    /**
     * Gets the string payload for the packet.
     *
     * @return the payload as a String
     */
    public String getPayload()
    {
	return _payload;
    }


    /**
     * Packet dumping function for verbose output.
     */
    public void dump()
    {
	System.out.println( "\n============================================" );
	System.out.println( "Packet Header : " + _header.getDelimitedString() );
	System.out.println( "packet type   : " + _header.getType() );
	System.out.println( "payload size  : " + _header.getSize() );
	System.out.println( "payload data  : " + _payload );
	System.out.println( "============================================" );
    }
}
