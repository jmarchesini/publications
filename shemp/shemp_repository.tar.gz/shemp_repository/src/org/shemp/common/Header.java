/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.common;

import java.io.*;
import java.util.*;


/**
 * Header for packets which contains type
 * and size of the whole packet in bytes.
 */
public class Header
{   
    private String _type;
    private char[] _size;
    private String _delim;

    static private int MAX_SIZE = 10;
    static private int _headersize = 17;


    /**
     * This constructor is used by the packetsto create a new Header
     * for their specific type.  So far, we have UAUTH, PCREQ, ECRPT,
     * DCRPT, and LOGOF for the types.
     *
     * @param type the type of packet: UAUTH, PCREQ, ECRPT, DCRPT, LOGOF
     */
    public Header( String type )
    {
	_type = type;
	_size = new char[MAX_SIZE];
	_delim = "|";
    }


    /**
     * This is used to construct a header from a raw byte stream 
     * (e.g., from a socket read).
     *
     * @param buf the raw byte stream (presumably from a socket)
     */
    public Header( byte[] buf )
    {
	_size = new char[MAX_SIZE];
	_delim = "|";

	String strbuf = new String( buf );
	StringTokenizer st = new StringTokenizer( strbuf, _delim );

	_type = st.nextToken();
 
	String size = st.nextToken();
	this.setSize( Integer.parseInt(size) );
    }


    /**
     * This is for packets to use so that they can
     * squash the header in order to send it over
     * a socket.
     *
     * @return the String version of a Header
     */
    public String getDelimitedString()
    {
	String strbuf = "";

	strbuf += _type;
	strbuf += _delim;
	strbuf += new String( _size );
	strbuf += _delim;

	return strbuf;
    }


    /**
     * This enables classes reading from a socket
     * to determine the exact size of the header.
     * Note that the header size is fixed.
     *
     * @return the Header's size
     */
    public static int getHeaderSize()
    {
	return _headersize;
    }


    /**
     * Because the Header's size is fixed, there
     * has to be a constant size way to represent
     * the size of the following packet.  This method
     * takes an int and stores it in an array of
     * MAX_SIZE characters, padding with leading zeroes
     * if necessary.
     *
     * @param size the number of characters in the payload
     */
    public void setSize( int size )
    {
	String strsize = String.valueOf( size );
	char[] charsize = strsize.toCharArray();
	int padlen = _size.length - charsize.length;

	int i;

	for (i = 0; i < padlen; ++i)
	{
	    _size[i] = '0';
	}

	for ( ; i < _size.length ; ++i)
	{
	    _size[i] = charsize[i - padlen];
	}
    }


    /**
     * Gets the number of characters in the payload.
     *
     * @return the number of characters in the payload
     */
    public int getSize()
    {
	String str = new String( _size );
	return Integer.parseInt( str );
    }


    /**
     * Gets the type of the packet: UAUTH, PCREQ, ECRPT, DCRPT, LOGOF
     *
     * @return the type
     */
    public String getType()
    {
	return _type;
    }
}
