/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.common;

import java.io.*;
import java.util.*;


/**
 * Utility class for reading/writing files.
 */
public class FileUtil
{ 

    /**
     * Public method used to read a file
     *
     * @param file the filename to read
     * @return the contents of the file as a String
     * @throws IOException if the file could not be read
     */
    static public String read( String file ) throws IOException
    {
	BufferedReader in = new BufferedReader( new FileReader(file) );
	String templine = in.readLine();
	String result = "";

	while (templine != null)
	{
	    result += templine.trim();
	    templine = in.readLine();
	}

	in.close();

	return result;
    }


    /**
     * Public method used to write a file.
     *
     * @param file the filename to read
     * @throws IOException if the file could not be read
     */
    static public void write( String file, String contents ) throws IOException
    {
	PrintWriter out = new PrintWriter( new BufferedWriter(
					   new FileWriter(file)) );
	out.write( contents );
	out.flush();
	out.close();
    }


    /**
     * Reads raw bytes from a file and puts them in a byte[].  This
     * is handy for reading sigs from a file.
     *
     * @param filename the name of the file to read
     * @return the byte array containing the file contents
     * @throws IOException if the file could not be read
     */
    static public byte [] readBytes( String filename ) throws IOException
    {
	File f = new File( filename );
	DataInputStream in = new DataInputStream( new FileInputStream(f) );
	byte [] filebytes = new byte[(int) f.length()];

	in.readFully( filebytes );
	in.close();

	return filebytes;
    }


    /**
     * Public method used to write a file.
     *
     * @param file the filename to read
     * @throws IOException if the file could not be read
     */
    static public void writeBytes( String file, byte [] contents )
	throws IOException
    {
	FileOutputStream out = new FileOutputStream( file );

	out.write( contents );
	out.flush();
	out.close();
    }
}
