/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Puts the arguments from the conf file into the private members
 * of this class.
 */
public class ConfigOptions
{
    static private ConfigOptions _instance = null;

    private int _port;
    private int _initial_threads;

    private String _logfile;
    private String _password;
    private String _keystore;
    private String _delim;
    private String _pwfile;
    private String _certdir;
    private String _userstore;
    private String _userpword;

    private boolean _verbose;


    /**
     * Use the instance() method to construct.  
     */
    protected ConfigOptions()
    {
	_port = 42174;
	_initial_threads = 5;
	_logfile = "/var/log/shemp.log";
	_verbose = false;
	_password = "";
	_keystore = "";
	_delim = "|";
	_pwfile = "";
	_certdir = "";
	_userstore = "";
	_userpword = "";
    }


    /**
     * Callers use this method to aquire an instance of a
     * ConfigOptions object.
     *
     * @return a valid ConfigOptions instance
     */
    public synchronized static ConfigOptions instance()
    {
	if (_instance == null)
	{
	    _instance = new ConfigOptions();
	}

	return _instance;
    }


    /**
     * Sets the port to listen for requests.
     *
     * @param str the String version of the port
     */
    public void setPort( String str )
    {
	 _port = Integer.parseInt( str );
    }
  

    /**
     * Sets the number of threads to spawn initially.
     *
     * @param str the String version of the number of threads
     */
    public void setThreads( String str )
    {
	_initial_threads = Integer.parseInt( str );
    }
  

    /**
     * Sets the location of the keystore.
     *
     * @param str the path to the keystore
     */
    public void setKeystore( String str )
    {
	_keystore = str;
    }
  

    /**
     * Sets the password for the keystore
     *
     * @param str the password
     */
    public void setPassword( String str )
    {
	_password = str;
    }
  

    /**
     * Sets the logfile location.
     *
     * @param str the path to the logfile
     */
    public void setLogfile( String str )
    {
	_logfile = str;
    }


    /**
     * Sets the verbose logging flag.
     *
     * @param str the String version of the verbose flag 
     */
    public void setVerbose( String str )
    {
	if (str.equals("true"))
	{
	    _verbose = true;
	}
    }


    /**
     * Sets the password file location.
     *
     * @param str the path to the password file
     */
    public void setPwFile( String str )
    {
	_pwfile = str;
    }


    /**
     * Sets the certificate directory
     *
     * @param str the path to the certificate directory
     */
    public void setCertDir( String str )
    {
	_certdir = str;
    }


    /**
     * Sets the location of the user keystore
     *
     * @param str the path to the user keystore
     */
    public void setUserstore( String str )
    {
	_userstore = str;
    }


    /**
     * Sets the password on the user keystore
     *
     * @param str the password for the user keystore
     */
    public void setUserPword( String str )
    {
	_userpword = str;
    }


    /**
     * Gets the port that the network slave uses to listen
     * for requests from other network slaves.
     *
     * @return the port
     */
    public int getPort()
    {
	return _port;
    }


    /**
     * Gets the number of threads to spawn initially.
     *
     * @return the number of threads
     */
    public int getThreads()
    {
	return _initial_threads;
    }


    /**
     * Gets the password for the keystore
     *
     * @return the password
     */
    public String getPassword()
    {
	return _password;
    }


    /**
     * Gets the location of the keystore.
     *
     * @return the path to the keystore
     */    
    public String getKeystore()
    {
	return _keystore;
    }


    /**
     * Gets the delimiter character(s) used in the packets.
     *
     * @return the delimiter
     */
    public String getDelim()
    {
	return _delim;
    }


    /**
     * Gets the path to the logfile
     *
     * @return the logfile
     */
    public String getLogfile()
    {
	return _logfile;
    }


    /**
     * Gets the verbose flag for logging
     *
     * @return the flag
     */
    public boolean getVerbose()
    {
	return _verbose;
    }


    /**
     * Gets the location of the password file.
     *
     * @return the path to the password file
     */    
    public String getPwFile()
    {
	return _pwfile;
    }


    /**
     * Gets the location of the certifiicate directory
     *
     * @return the path to the certificate directory
     */    
    public String getCertDir()
    {
	return _certdir;
    }


    /**
     * Gets the location of the user keystore
     *
     * @return the path to the user keystore
     */    
    public String getUserstore()
    {
	return _userstore;
    }


    /**
     * Gets the password for the user keystore
     *
     * @return the password for the user keystore
     */    
    public String getUserPword()
    {
	return _userpword;
    }


    /**
     * Used for debugging only.
     */
    public void dumpConfig()
    {
	System.out.println( "DumpConfig" );
	System.out.println( "Port: " + _port );
	System.out.println( "Threads: " + _initial_threads );
	System.out.println( "Keystore: " + _keystore );
	System.out.println( "Password: " + _password );
	System.out.println( "Logfile: " + _logfile );
	System.out.println( "Verbose: " + _verbose );
	System.out.println( "Password File: " + _pwfile );
	System.out.println( "Certificate Directory: " + _certdir );
	System.out.println( "Userstore: " + _userstore );
	System.out.println( "User Keystore Password: " + _userpword );	
    }
}

