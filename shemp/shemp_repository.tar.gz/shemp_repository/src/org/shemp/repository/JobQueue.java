/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.util.*;


/**
 * This class implements a Queue where jobs are
 * placed and removed by threads.  It is a generic
 * structure used by the ThreadPool.
 */
public class JobQueue
{
    private LinkedList _jobs = new LinkedList();
    private boolean _closed = false;


    /**
     * This is the entry point to the thread pool.
     * Enqueuing a job puts it on the queue and the
     * next available WorkerThread takes it off for
     * processing.
     *
     * @param job an Object to be enqueued
     * @throws QueueClosedException if the Queue is closed
     */
    public synchronized void enqueue( Object job )
	throws QueueClosedException
    {
	if (!_closed)
	{
	    _jobs.addLast( job );
	    notify();
	}
	else
	{
	    throw new QueueClosedException();
	}
    }


    /**
     * This is where WorkerThreads pick up jobs.
     *
     * @return the Object to execute
     * @throws InterruptedException if the thread is interrupted
     * @throws QueueClosedException if the Queue is closed
     */
    public synchronized Object dequeue()
	throws InterruptedException, QueueClosedException
    {
	try
	{
	    while (_jobs.size() <= 0)
	    {
		wait();
		
		if (_closed)
		{
		    throw new QueueClosedException();
		}
	    }
	    return _jobs.removeFirst();
	}
	catch( NoSuchElementException e )
	{
	    throw new Error( "NoSuchElement in JobQueue" );
	}
    }
    

    /**
     * Only the thread pool should call this, obviously.
     * Set the closed bit and release all the waiting
     * WorkerThreads.
     */
    public synchronized void shutdown()
    {
	_closed = true;
	notifyAll();
    }


    /**
     * Tells whether the JobQueue is empty.
     *
     * @return boolean specifying whether the JobQueue is empty
     */
    public synchronized boolean isEmpty()
    {
	return (_jobs.size() > 0);
    }
}
