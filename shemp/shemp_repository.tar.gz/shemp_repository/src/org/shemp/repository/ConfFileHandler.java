/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.io.*;
import java.lang.*;
import java.util.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;


/**
 * This is the core of the config file parser.  Standard
 * SAX parser is used to parse the config file.
 */
public class ConfFileHandler extends DefaultHandler
{
    private String _currentElement = null;
    private String _configFile = "";

    private ConfigOptions _co;


    /**
     * @param conffile a pathname to the configuration file
     * @throws IOException if the file cannot be opened
     */
    public ConfFileHandler( String conffile ) throws IOException
    {
	BufferedReader in = new BufferedReader( new FileReader(conffile) );
	String templine = in.readLine();

	while (templine != null)
	{
	    _configFile += templine.trim();
	    templine = in.readLine();
	}

	in.close();
    }


    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     */
    public void startDocument() throws SAXException
    {
	_co = ConfigOptions.instance();
    }


    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *    
     * @throws SAXException if a parse error occurs
     */    
    public void endDocument() throws SAXException {}

    
    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void startElement( String uri, String localName,
			      String qName, Attributes attributes )
        throws SAXException 
    {
	_currentElement = qName;
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void endElement( String uri, String localName, String qName )
        throws SAXException
    {}
    

    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void characters( char[] ch, int start, int length )
        throws SAXException
    {
	if ("port".equals(_currentElement))
	{
	    _co.setPort( new String(ch, start, length) );
	}
	else if ("threads".equals(_currentElement))
	{
            _co.setThreads( new String(ch, start, length) );
	}
	else if ("keystore".equals(_currentElement))
	{
	    _co.setKeystore( new String(ch, start, length) );
	}
	else if ("password".equals(_currentElement))
	{
	    _co.setPassword( new String(ch, start, length) );
	}
	else if ("logfile".equals(_currentElement))
	{
	    _co.setLogfile( new String(ch, start, length) );
	}
	else if ("verbose".equals(_currentElement))
	{
	    _co.setVerbose( new String(ch, start, length) );
	}
	else if ("pwfile".equals(_currentElement))
	{
	    _co.setPwFile( new String(ch, start, length) );
	}
	else if ("certdir".equals(_currentElement))
	{
	    _co.setCertDir( new String(ch, start, length) );
	}
	else if ("userstore".equals(_currentElement))
	{
	    _co.setUserstore( new String(ch, start, length) );
	}
	else if ("userpword".equals(_currentElement))
	{
	    _co.setUserPword( new String(ch, start, length) );
	}
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void error( SAXParseException e )
        throws SAXException
    {
        e.printStackTrace();
    }


    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */    
    public void fatalError( SAXParseException e )
        throws SAXException
    {
        e.printStackTrace();
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * conffile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void warning( SAXParseException e )
        throws SAXException
    {
        e.printStackTrace();
    }


    /**
     * This method returns the unparsed configuration file as a String.
     *
     * @return the unparsed file as a String
     */
    public String getFileAsStr()
    {
	return _configFile;
    }
}
