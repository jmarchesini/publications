/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved.
 * Copyright 2003-2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1. Redistribution of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 * 
 *   2. Redistribution in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MICROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE,
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 * You acknowledge that this software is not designed or intended for use in
 * the design, construction, operation or maintenance of any nuclear facility.
 */
package org.shemp.repository;

import org.shemp.common.*;

import java.io.*;
import java.net.*;
import java.util.*;

import com.sun.xacml.*;
import com.sun.xacml.cond.*;
import com.sun.xacml.ctx.*;
import com.sun.xacml.finder.*;
import com.sun.xacml.finder.impl.*;


/**
 * This class is where the XACML policy decisions are made.  Basically,
 * this class wraps up an XACML PDP.  Many concepts and much code is
 * borrowed from Seth Proctor's SimplePDP class in the SunXACML package.
 * Many thanks to Seth and Sun for their work on the SunXACML project,
 * writing that from scratch would have added years to my dissertation.
 */
public class PolicyDecider
{
    private PDP _pdp = null;

    /**
     * Constructor that takes an array of filenames, each of which
     * contains an XACML policy, and sets up a <code>PDP</code> with access
     * to these policies only. The <code>PDP</code> is configured
     * programatically to have only a few specific modules.
     *
     * @param policyFile a filename where the policy is stored
     * @throws Exception if something bad happens
     */
    public PolicyDecider( String policyFile ) throws Exception
    {   
        FilePolicyModule filePolicyModule = new FilePolicyModule();
	filePolicyModule.addPolicy( policyFile );

        // next, setup the PolicyFinder that this PDP will use
        PolicyFinder policyFinder = new PolicyFinder();
        Set policyModules = new HashSet();
        policyModules.add( filePolicyModule );
        policyFinder.setModules( policyModules );

        // now setup attribute finder modules for the current date/time and
        // AttributeSelectors (selectors are optional, but this project does
        // support a basic implementation)
        CurrentEnvModule envAttributeModule = new CurrentEnvModule();
        SelectorModule selectorAttributeModule = new SelectorModule();

        // Setup the AttributeFinder just like we setup the PolicyFinder. Note
        // that unlike with the policy finder, the order matters here. See the
        // the javadocs for more details.
        AttributeFinder attributeFinder = new AttributeFinder();
        List attributeModules = new ArrayList();
        attributeModules.add( envAttributeModule );
        attributeModules.add( selectorAttributeModule );
        attributeFinder.setModules( attributeModules );

        _pdp = new PDP( new PDPConfig(attributeFinder, policyFinder, null) );
    }


    /**
     * Evaluates the given request and returns the Response that the PDP
     * will hand back to the PEP.
     *
     * @param request the RequestCtx that holds the request
     * @return the result of the evaluation
     */
    public ResponseCtx evaluate( RequestCtx request )
    {
        return _pdp.evaluate( request );
    }
}
