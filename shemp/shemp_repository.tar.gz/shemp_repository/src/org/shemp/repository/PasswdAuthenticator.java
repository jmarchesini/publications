/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;

import javax.net.*;
import javax.net.ssl.*;

import org.shemp.common.*;


/**
 * This is the how the repository verifies a user's login and password.
 */
public class PasswdAuthenticator
{
    private InputStream _in = null;
    private OutputStream _out = null;


    /**
     * Sets up a new PasswdAuthenticator.
     *
     * @param in the InputStream to the client
     * @param out the OutputStream to the client
     */
    public PasswdAuthenticator( InputStream in, OutputStream out )
    {
	_in = in;
	_out = out;
    }


    /**
     * This method begins the authentication protocol.
     *
     * @param pkt the Packet which begins a new authentication session
     * @return the login name of the user
     * @throws Exception if any errors occur---this shuts down the socket
     */
    public String authenticate( Packet pkt ) throws Exception
    {
	long sleeptime = 1000;
	boolean authenticated = false;
	String username = "";

	while (authenticated == false)
	{
	    if (isNewRequest( pkt ) == false)
	    {
		throw new Exception( "Malformed authentication request." );
	    }

	    // We need to send a challenge to the client
	    Packet challenge = new Packet( "UAUTH", "login: " );
	    PacketComm.send( challenge, _out );

	    // Block until we get a reply---contains username
	    Packet reply = PacketComm.recv( _in );
	    username = reply.getPayload();

	    // Send a continue message
	    Packet cont = new Packet( "UAUTH", "CONTINUE" );
	    PacketComm.send( cont, _out );

	    // Block until we get a reply---contains username
	    Packet blank = PacketComm.recv( _in );

	    // Prompt for a password
	    Packet pwchallenge = new Packet( "UAUTH", "password: " );
	    PacketComm.send( pwchallenge, _out );

	    // Block until we get a reply---contains username
	    Packet pwreply = PacketComm.recv( _in );
	    String password = pwreply.getPayload();

	    // Do the check
	    if (isValid( username, password ) == true)
	    {
		authenticated = true;
		Packet auth = new Packet( "UAUTH", "AUTHENTICATED" );
		PacketComm.send( auth, _out );
	    }
	    else
	    {
		// Backoff --- make the client wait
		sleeptime = 2 * sleeptime;
		Thread.sleep( sleeptime );
		
		// Send continue and get the authentication request
		PacketComm.send( cont, _out );
		pkt = PacketComm.recv( _in );

		username = "";
	    }
	}

	return username;
    }


    /**
     * This private method is used to check if the new authentication
     * request is valid.
     *
     * @param pkt the packet to inspect
     * @return true if valid, false otherwise
     */
    private boolean isNewRequest( Packet pkt )
    {
	if ("UAUTH".compareToIgnoreCase( pkt.getType() ) != 0 ||
	    "AUTHENTICATE".compareToIgnoreCase( pkt.getPayload() ) != 0)
	{
	    return false;
	}
	
	return true;
    }


    /**
     * This method will check the etc/passwd file for the username
     * password.
     *
     * @param username the username to check
     * @param password the password to check
     * @return true if the username/password are valid, false otherwise
     */
    private boolean isValid( String username, String password )
	throws Exception
    {
	String pwdigest = getDigest( password );
	String needle = username + "::" + pwdigest;

	return isInHaystack( needle );
    }


    /**
     * This private method is used to compute a SHA-1 digest for the
     * input string.
     *
     * @param password the String to compute a digest of
     * @return SHA1(password)
     * @throws NoSuchAlgorithmException if SHA-1 is not found
     */
    private String getDigest( String password ) throws NoSuchAlgorithmException
    {
	MessageDigest sha = MessageDigest.getInstance("SHA-1");
	sha.update( password.getBytes() );
	byte[] digest = sha.digest();

	StringBuffer hexString = new StringBuffer();

        for (int i = 0; i < digest.length; i++)
	{
            String plainText = Integer.toHexString( 0xFF & digest[i] );

            if (plainText.length() < 2)
	    {
                plainText = "0" + plainText;
            }

            hexString.append( plainText );
        }

	return hexString.toString();
    }


    /**
     * This private method opens the password file, and checks each
     * line to see if the needle matches.  It's inefficient to read
     * the whole file on each login as we do here, but it's the best
     * way to be sure that TOCTOU issues don't arise.
     *
     * @param needle the line to search for
     * @return true if the needle is in the file, false otherwise
     * @throws IOException if the password file can't be opened
     */
    private boolean isInHaystack( String needle ) throws IOException
    {
	BufferedReader in = new BufferedReader( new FileReader(
				   ConfigOptions.instance().getPwFile()) );

	String templine = in.readLine();

	while (templine != null)
	{
	    if ((templine.trim()).equals( needle ))
	    {
		in.close();
		return true;
	    }

	    templine = in.readLine();
	}

	in.close();

	return false;
    }
}
