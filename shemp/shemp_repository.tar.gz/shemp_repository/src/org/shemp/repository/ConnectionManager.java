/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.net.*;
import javax.net.ssl.*;


/**
 * This class is used to implement a generic connection manager
 * which takes requests and dispatches them to threads in a
 * ThreadPool.
 */
public class ConnectionManager extends Thread
{
    private ServerSocket _server_sock;
    private ThreadPool _pool;
    private Class _handler;
    private LinkedList _connection_cache = new LinkedList();


    /**
     * All handlers should implement this interface.  A
     * Connection will call the execute method once it
     * receives a request.
     *
     * Since Handlers deal with specific connections, they
     * are allowed to have state.  Since they are recycled,
     * they need to be initialized on each dispatch.
     */
    public interface Handler
    {
	void initialize( Socket socket );
	void execute();
    }


    /**
     * These connections are cached in the _connection_cache.
     * When a request comes in, the ConnectionManager gets a
     * connection from the cache, calls setSocket() to give
     * it it's socket, and throws it to the _pool, which will
     * assign it to a thread and call it's run() method.
     * The Connection's run() method calls the handler's
     * initialize() and execute(), and the handler does its 
     * thing.
     */
    private class Connection implements Runnable
    {
	private Handler _handler;
	private Socket _socket;


	/**
	 * @param h the underlying Handler to be invoked
	 */
	Connection( Handler h )
	{
	    _handler = h;
	}


	/**
	 * @param s the socket to receive a request from
	 */
	public void setSocket( Socket s )
	{
	    _socket = s;
	}

       
	public void run()
	{
	    _handler.initialize( _socket );
	    _handler.execute();

	    synchronized( _connection_cache )
	    {
		_connection_cache.addLast( this );
	    }
	}
    }


    /**
     * Get a socket from the server, and set up a cache full of
     * Connections.  We go to sleep until we get a request on
     * the SSLServerSocket.  Then, the run() method is called.
     *
     * @param sock the ServerSocket to receive requests on
     * @param expected_conns the initial number of threads to spawn
     * @param handler is the type of handler that the ConnectionManager
     *                dispatches
     */
    public ConnectionManager( ServerSocket sock, int expected_conns,
			      Class handler )
    {
	try
	{
	    _server_sock = sock;
	    _pool = new ThreadPool( expected_conns, Integer.MAX_VALUE );
	    _handler = handler;

	    for (int idx = 0; idx < expected_conns ; ++idx)
	    {
		_connection_cache.addLast( 
		    new Connection( (Handler)(handler.newInstance())) );
	    }

	    setDaemon( true );
	}
	catch( Exception e )
	{
	    throw new Error( "ERROR: ConnectionManager was not crested." );
	}
    }


    /**
     * The idea here is that when an accept() happens, we will
     * try to peel a Connection out of the cache, set up the
     * socket, and give it to the pool, which calls the
     * Connection's run().
     */
    public void run()
    {
	try
	{
	    Connection conn;

	    while (!isInterrupted())
	    {
		synchronized( _connection_cache )
		{
		    if (_connection_cache.size() > 0)
		    {
			conn = (Connection)(_connection_cache.removeLast());
		    }
		    else
		    {
			conn = 
			    new Connection((Handler)(_handler.newInstance()));
		    }
		}

		conn.setSocket( _server_sock.accept() );
		
		if (isInterrupted())
		{
		    break;
		}

		_pool.execute( conn );
	    }
	}
	catch( Exception e )
	{
	    System.out.println( e.toString() );
	    throw new Error( "ERROR: ConnectionManager shutting down." );
	}
	finally
	{
	    _pool.shutdown();
	}
    }
 

    /**
     * Graceful shutdown.
     */
    public void shutdown()
    {
	try
	{
	    _pool.shutdown();
	    interrupt();
	    _server_sock.close();
	}
	catch( Exception e ) {}
    }
}
