/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;

import java.io.*;

import javax.xml.parsers.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;


/**
 * This class is used to drive the parsers in the system.
 */
public class SaxParserDriver 
{
    /**
     * @param xmlfrag the XML fragment or file to parse
     * @param handler the handler used for parsing
     * @throws ParserConfigurationException if the parser is misconfigured
     * @throws IOException if the xmlfrag cannot be read
     * @throws SAXException if there is a parse error
     */
    SaxParserDriver( String xmlfrag, DefaultHandler handler )
        throws ParserConfigurationException, IOException, SAXException
    {
	XMLReader reader = getReader();

        reader.setContentHandler( handler );
        reader.setErrorHandler( handler );
        reader.setDTDHandler( handler );        
	reader.parse( new InputSource(new StringReader(xmlfrag)) );
    }
    

    /**
     * Gets a new SAXParser from org.xml.SAXParserFactory.
     *
     * @return an XMLReader
     * @throws ParserConfigurationException if the parser is misconfigured
     * @throws SAXException if there is a parse error
     */
    private XMLReader getReader() 
	throws ParserConfigurationException, SAXException 
    {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser = factory.newSAXParser();
        
	return parser.getXMLReader();
    }
}
