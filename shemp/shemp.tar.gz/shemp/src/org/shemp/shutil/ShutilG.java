/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;
import org.shemp.common.*;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import javax.swing.*;          
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


/**
 * This is a demo application that shows how to use the SHEMP API
 * (Shapi) to work with a SHEMP repository.  This is graphical version
 * of the Shutil tool.
 */
public class ShutilG extends JPanel
{
    private JTabbedPane tabbedPane = null;
    private static Shapi api = null;


    /**
     * The constructor sets up the tabs and dimensions.
     * The operation tabs are disabled by default.
     */
    public ShutilG()
    {
        super( new GridLayout(1, 1) );
        tabbedPane = new JTabbedPane();

        JComponent panel1 = new SessionPanel( tabbedPane, api );
	panel1.setPreferredSize( new Dimension(600, 400) );
        tabbedPane.addTab( "Session", null, panel1, 
			   "Connect to a Shemp repository" );
        tabbedPane.setMnemonicAt( 0, KeyEvent.VK_1 );

        JComponent panel2 = new PCPanel( api );
        tabbedPane.addTab( "Generate", null, panel2,
			   "Generate a Proxy Certificate" );
        tabbedPane.setMnemonicAt( 1, KeyEvent.VK_2 );

        JComponent panel3 = new DecryptPanel( api );
        tabbedPane.addTab( "Decrypt", null, panel3,
			   "Use the decryption proxy service" );
        tabbedPane.setMnemonicAt( 2, KeyEvent.VK_3 );

        JComponent panel4 =  new SignPanel( api );
        tabbedPane.addTab( "Sign", null, panel4,
			   "Use the signing proxy service");
        tabbedPane.setMnemonicAt( 3, KeyEvent.VK_4 );

        this.add( tabbedPane );

	//Disable the last 3 tabs
	tabbedPane.setEnabledAt(1, false);
	tabbedPane.setEnabledAt(2, false);
	tabbedPane.setEnabledAt(3, false);
    }


    /**
     * Create the GUI and show it.  It activates the Session
     * tab by default and grays the others out.
     */
    private static void createAndShowGUI()
    {
        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated( true );

        //Create and set up the window.
        JFrame frame = new JFrame( "SHUTIL" );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        //Create and set up the content pane.
        JComponent newContentPane = new ShutilG();
        newContentPane.setOpaque( true );
        frame.getContentPane().add( new ShutilG(), BorderLayout.CENTER );

        //Display the window.
        frame.pack();
        frame.setVisible( true );
    }


    public static void main( String[] args )
    {
	String conffile = "";
	String choice = "";

	if (args.length != 1)
	{
	    System.out.println( 
		"USAGE: java ShutilG <conffile>" );
	    System.exit( -1 );
	}
	else 
	{
	    conffile = args[0];
	}

	// Parse Config File and populate ConfigOptions
	ConfigOptions co = ConfigOptions.instance();

	try
	{
	    ConfFileHandler handler = new ConfFileHandler( conffile );
	    SaxParserDriver parser = 
		new SaxParserDriver( handler.getFileAsStr(), handler );
	}
	catch( Exception e )
	{
	    System.err.println( "Unable to parse configuration file." );
	    System.exit( -1 );
	}

	api = new Shapi( co.getKeystore(), co.getPassword() );

        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater( new Runnable()
	{
            public void run()
	    {
		createAndShowGUI();
            }
        });
    }
}
