/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;
import org.shemp.common.*;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.*;
import javax.swing.*;          
import java.awt.*;
import java.awt.event.*;

/**
 * This is the class that handles the Sign tab which is used
 * to send a signed a PC, a message, and a signed SHA-1 of the
 * message to the repository (signed with the private key descibed by
 * the PC).  The repostitory verifies the signature with the PC, does
 * a policy check, and if allowed, signs the message with the user's
 * long-key private key.
 */
public class SignPanel extends JPanel
{   
    private JTextField _msgField;
    private JTextField _sigField;
    private JTextField _resultField;
    private JTextArea _console;
    private JButton _signButton;
    private JButton _msgButton;
    private JButton _sigButton;
    private JButton _resultButton;
    private JFileChooser _chooser;

    private String _msgFile;
    private String _sigFile;
    private String _resultFile;

    private Shapi _api;

    private static String _msgLabel = "Message File";
    private static String _sigLabel = "Signature File";
    private static String _resultLabel = "Result File";


    /**
     * This handler contacts the decryption proxy service
     */
    public class Connect implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    try
	    {
		_console.append( "Calling the signing proxy.\n" );

		String utildir =  ConfigOptions.instance().getUtilDir();
		String crtfile = utildir + "/tempkey.cer";
		String cert = FileUtil.read( crtfile );
		String msgfile = _msgField.getText();
		byte [] msg = FileUtil.readBytes( msgfile );
		String sigfile = _sigField.getText();
		byte [] sig = FileUtil.readBytes( sigfile );
		String newsig = _api.sign( msg, sig, cert );

		if (newsig.compareToIgnoreCase("POLICY_FAIL") == 0)
		{
		    _console.append( "The signing request was denied due to " +
				     "the user's policy and current " +
				     "environment.\nThe message was not " +
			             "signed.\n" );
		}
		else
		{
		    String resfile = _resultField.getText();
		    
		    BASE64Decoder b64d = new BASE64Decoder();
		    FileUtil.writeBytes( resfile, b64d.decodeBuffer(newsig) ); 

		    _console.append( "The following was written to: " +
				     resfile + " and can be verified " +
			             "with your long term public key.\n\n" );
		    _console.append( newsig );
		}
	    }
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}
    }


    /**
     * This handler deals with the "Browse" button events.
     */
    public class OpenFile implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    int returnVal = _chooser.showOpenDialog( SignPanel.this );

            if (returnVal == JFileChooser.APPROVE_OPTION)
	    {
                File file = _chooser.getSelectedFile();

		if (e.getSource() == _msgButton)
		{
		    _msgField.setText( "" );
		    _msgField.setText( file.getAbsolutePath() );
		}
		else if (e.getSource() == _sigButton)
		{
		    _sigField.setText( "" );
		    _sigField.setText( file.getAbsolutePath() );
		}
		else if (e.getSource() == _resultButton)
		{
		    _resultField.setText( "" );
		    _resultField.setText( file.getAbsolutePath() );
		}
            }
	}
    }

    
    /**
     * This builds the Sign tab, and registers all of the handlers.
     *
     * @param api the Shapi object
     */
    public SignPanel( Shapi api )
    {
        super( new BorderLayout() );

	// The files area
        _msgField = new JTextField( 10 );
        _msgField.setActionCommand( _msgLabel );
        _sigField = new JTextField( 10 );
        _sigField.setActionCommand( _sigLabel );
        _resultField = new JTextField( 10 );
        _resultField.setActionCommand( _resultLabel );
        
        JLabel msgLabel = new JLabel( _msgLabel + ": " );
        msgLabel.setLabelFor( _msgField );
	JLabel sigLabel = new JLabel( _sigLabel + ": " );
	sigLabel.setLabelFor( _sigField );
        JLabel resultLabel = new JLabel( _resultLabel + ": " );
        resultLabel.setLabelFor( _resultField );

	_msgButton = new JButton( "Browse" );
	_msgButton.addActionListener( new OpenFile() );
	_sigButton = new JButton( "Browse" );
	_sigButton.addActionListener( new OpenFile() );
	_resultButton = new JButton( "Browse" );
	_resultButton.addActionListener( new OpenFile() );

        JPanel textControlsPane = new JPanel();
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        textControlsPane.setLayout( gridbag );

        JLabel[] labels = { msgLabel, sigLabel, resultLabel };
        JTextField[] textFields = { _msgField, _sigField, _resultField };
	JButton[] buttons = { _msgButton, _sigButton, _resultButton };
        addLabelTextRows( labels, textFields, buttons,
			  gridbag, textControlsPane );

        c.gridwidth = GridBagConstraints.REMAINDER;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = 1.0;

        textControlsPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder("File Location"),
	    BorderFactory.createEmptyBorder(5,5,5,5) ));

	// Create the console area
	JPanel consolePane = new JPanel();
	consolePane.setLayout( new BorderLayout() );

	_console = new JTextArea( 
	    "This service will verify a message which was signed with " +
	    "your short-term private key.  It will then resign it with " +
	    "your long-term private key and write the result to the " +
	    "result file.\n\n" );

        _console.setLineWrap( true );
        _console.setWrapStyleWord( true );
	_console.setEditable( false );

        JScrollPane areaScrollPane = new JScrollPane( _console );	
        areaScrollPane.setVerticalScrollBarPolicy(
	    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        areaScrollPane.setPreferredSize( new Dimension(190, 190) );

	consolePane.add( areaScrollPane, BorderLayout.CENTER );

        consolePane.setBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Console"),
            BorderFactory.createEmptyBorder(5,5,5,5)),
	    consolePane.getBorder() ));
       
	//Lay out the buttons
        JPanel buttonPane = new JPanel();
	buttonPane.setLayout( new GridLayout(1, 1) );
	buttonPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder( "" ),
	    BorderFactory.createEmptyBorder(15,10,15,10) ));

	_signButton = new JButton( "Sign" );
        _signButton.setMnemonic( KeyEvent.VK_D );
        _signButton.addActionListener( new Connect() );
	buttonPane.add( _signButton );

	add( textControlsPane, BorderLayout.PAGE_START );
	add( consolePane, BorderLayout.CENTER );
	add( buttonPane, BorderLayout.PAGE_END );

	_api = api;
	_chooser = new JFileChooser();
	_chooser.setFileSelectionMode( JFileChooser.FILES_AND_DIRECTORIES );
    }


    /**
     * A Sun Microsystems function from the SwingAPI demos used
     * to add labels to text fields.
     *
     * @param labels an array of JLabels
     * @param textFields an array of JTextFields to apply the labels to
     * @param buttons an array of buttons
     * @param gridbag a GridBagLayout to place the fields in
     * @param container the container where everything goes
     */
    private void addLabelTextRows( JLabel[] labels,
                                   JTextField[] textFields,
				   JButton[] buttons,
                                   GridBagLayout gridbag,
                                   Container container )
    {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.WEST;

        int numLabels = labels.length;

        for (int i = 0; i < numLabels; i++)
	{
	    int j = 0;

	    c.weightx = 0.0;
	    c.gridx = j++;
	    c.gridy = i;
	    container.add( labels[i], c);

	    c.fill = GridBagConstraints.HORIZONTAL;
	    c.gridx = j++;
	    c.gridy = i;
	    c.weightx = 1.0;
            container.add( textFields[i], c );
	    
	    c.gridx = j;
	    c.gridy = i;
	    c.weightx = 0.0;
	    container.add( buttons[i], c );
        }
    }
}
