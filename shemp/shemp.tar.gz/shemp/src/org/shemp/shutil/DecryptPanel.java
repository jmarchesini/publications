/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;
import org.shemp.common.*;

import java.io.*;
import javax.swing.*;          
import java.awt.*;
import java.awt.event.*;

/**
 * This is the class that handles the Decrypt tab which is used
 * to send an encrypted message and a PC to the repository.
 * The repository decrypts the message with the user's long term priv.
 * key, re-encrypts it with the pub. key in the PC, and returns it.
 * decrypt 
 */
public class DecryptPanel extends JPanel
{   
    private JTextField _msgField;
    private JTextField _resultField;
    private JTextArea _console;
    private JButton _decryptButton;
    private JButton _msgButton;
    private JButton _resultButton;
    private JFileChooser _chooser;

    private String _msgFile;
    private String _resultFile;

    private Shapi _api;

    private static String _msgLabel = "Message File";
    private static String _resultLabel = "Result File";


    /**
     * This handler contacts the decryption proxy service
     */
    public class Connect implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    try
	    {
		_console.append( "Calling the en/decryption proxy.\n" );

		String utildir =  ConfigOptions.instance().getUtilDir();
		String cipherfile = _msgField.getText();
		String ciphertext = FileUtil.read( cipherfile );
		String crtfile = utildir + "/tempkey.cer";
		String proxycert = FileUtil.read( crtfile );
		String result = _api.encrypt( ciphertext, proxycert );

		if (result.compareToIgnoreCase("POLICY_FAIL") == 0)
		{
		    _console.append( "The decryption request was denied " +
				     "due to the user's policy and current " +
				     "environment.\n" );
		    _console.append( "The message was not decrypted." );
		}
		else
		{
		    String resultfile = _resultField.getText();
		    FileUtil.write( resultfile, result );

		    _console.append( "The following was written to: " +
				     resultfile + " and can be decrypted " +
			             "with your temporary private key.\n\n" );
		    _console.append( result );
		}
	    }
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}
    }


    /**
     * This handler deals with the "Browse" button events.
     */
    public class OpenFile implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    int returnVal = _chooser.showOpenDialog( DecryptPanel.this );

            if (returnVal == JFileChooser.APPROVE_OPTION)
	    {
                File file = _chooser.getSelectedFile();

		if (e.getSource() == _msgButton)
		{
		    _msgField.setText( "" );
		    _msgField.setText( file.getAbsolutePath() );
		}
		else if (e.getSource() == _resultButton)
		{
		    _resultField.setText( "" );
		    _resultField.setText( file.getAbsolutePath() );
		}
            }
	}
    }

    
    /**
     * This builds the Decrypt tab, and registers all of the handlers.
     *
     * @param api the Shapi object
     */
    public DecryptPanel( Shapi api )
    {
        super( new BorderLayout() );

	// The files area
        _msgField = new JTextField( 10 );
        _msgField.setActionCommand( _msgLabel );
        _resultField = new JTextField( 10 );
        _resultField.setActionCommand( _resultLabel );
        
        JLabel msgLabel = new JLabel( _msgLabel + ": " );
        msgLabel.setLabelFor( _msgField );
        JLabel resultLabel = new JLabel( _resultLabel + ": " );
        resultLabel.setLabelFor( _resultField );

	_msgButton = new JButton( "Browse" );
	_msgButton.addActionListener( new OpenFile() );
	_resultButton = new JButton( "Browse" );
	_resultButton.addActionListener( new OpenFile() );

        JPanel textControlsPane = new JPanel();
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        textControlsPane.setLayout( gridbag );

        JLabel[] labels = { msgLabel, resultLabel };
        JTextField[] textFields = { _msgField, _resultField };
	JButton[] buttons = { _msgButton, _resultButton };
        addLabelTextRows( labels, textFields, buttons,
			  gridbag, textControlsPane );

        c.gridwidth = GridBagConstraints.REMAINDER;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = 1.0;

        textControlsPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder("File Location"),
	    BorderFactory.createEmptyBorder(5,5,5,5) ));

	// Create the console area
	JPanel consolePane = new JPanel();
	consolePane.setLayout( new BorderLayout() );

	_console = new JTextArea( 
	    "This service will decrypt a message which was encrypted " +
	    "with your long-term public key (i.e., the contents of the " +
	    "message file), and reencrypt it with your temporary public " +
	    "key.  The result will be written to the result file.\n\n" );

        _console.setLineWrap( true );
        _console.setWrapStyleWord( true );
	_console.setEditable( false );

        JScrollPane areaScrollPane = new JScrollPane( _console );	
        areaScrollPane.setVerticalScrollBarPolicy(
	    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        areaScrollPane.setPreferredSize( new Dimension(190, 190) );

	consolePane.add( areaScrollPane, BorderLayout.CENTER );

        consolePane.setBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Console"),
            BorderFactory.createEmptyBorder(5,5,5,5)),
	    consolePane.getBorder() ));
       
	//Lay out the buttons
        JPanel buttonPane = new JPanel();
	buttonPane.setLayout( new GridLayout(1, 1) );
	buttonPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder( "" ),
	    BorderFactory.createEmptyBorder(15,10,15,10) ));

	_decryptButton = new JButton( "Decrypt" );
        _decryptButton.setMnemonic( KeyEvent.VK_D );
        _decryptButton.addActionListener( new Connect() );
	buttonPane.add( _decryptButton );

	add( textControlsPane, BorderLayout.PAGE_START );
	add( consolePane, BorderLayout.CENTER );
	add( buttonPane, BorderLayout.PAGE_END );

	_api = api;
	_chooser = new JFileChooser();
	_chooser.setFileSelectionMode( JFileChooser.FILES_AND_DIRECTORIES );
    }


    /**
     * A Sun Microsystems function from the SwingAPI demos used
     * to add labels to text fields.
     *
     * @param labels an array of JLabels
     * @param textFields an array of JTextFields to apply the labels to
     * @param buttons an array of buttons
     * @param gridbag a GridBagLayout to place the fields in
     * @param container the container where everything goes
     */
    private void addLabelTextRows( JLabel[] labels,
                                   JTextField[] textFields,
				   JButton[] buttons,
                                   GridBagLayout gridbag,
                                   Container container )
    {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.WEST;

        int numLabels = labels.length;

        for (int i = 0; i < numLabels; i++)
	{
	    int j = 0;

	    c.weightx = 0.0;
	    c.gridx = j++;
	    c.gridy = i;
	    container.add( labels[i], c);

	    c.fill = GridBagConstraints.HORIZONTAL;
	    c.gridx = j++;
	    c.gridy = i;
	    c.weightx = 1.0;
            container.add( textFields[i], c );
	    
	    c.gridx = j;
	    c.gridy = i;
	    c.weightx = 0.0;
	    container.add( buttons[i], c );
        }
    }
}
