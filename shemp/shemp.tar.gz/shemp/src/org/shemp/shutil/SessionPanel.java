/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.shutil;

import org.shemp.shapi.*;
import org.shemp.common.*;

import javax.swing.*;          
import java.awt.*;
import java.awt.event.*;

/**
 * This is the class that handles the Session tab which is used
 * to connect and disconnect from repositories.
 */
public class SessionPanel extends JPanel
{   
    private JTabbedPane _tabbedPane;
    private JTextField _hostField;
    private JTextField _portField;
    private JPasswordField _responseField;
    private JTextArea _console;
    private JButton _sendButton;

    private String _hostName;
    private String _response;
    private String _port;

    private Shapi _api;

    private static String _hostnameLabel = "Hostname";
    private static String _portLabel = "Port";

    
    /**
     * This handler deals with sending messages such as login and
     * password to the repository.
     */
    public class Send implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    try
	    {
		String reply = _responseField.getText();
		_api.sendAuthReply( reply );
		_responseField.setText( "" );

		if (_api.authenticated() == false)
		{
		    _console.append( _api.getAuthChallenge() + "\n" );
		}
		else
		{
		    _console.append( "\nYou are authenticated.  You can " +
				     "use the Generate, Decrypt, and " +
				     "Sign tabs to perform operations.\n\n" );
  
		    _tabbedPane.setEnabledAt( 1, true );
		    _tabbedPane.setEnabledAt( 2, true );
		    _tabbedPane.setEnabledAt( 3, true );

		    _sendButton.removeActionListener( this );
		}
	    }
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}
    }


    /**
     * This is the handler for the Connect button.  It takes the
     * hostname/port and tries to connect.
     */
    public class Connect implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    _hostName = _hostField.getText();
	    _port = _portField.getText();

	    _console.append( "Connecting to: " + _hostName + ":" +
			     _port + "\n" );
	    try
	    {
		_api.connect( _hostName, Integer.parseInt(_port) );
		_console.append( _api.getAuthChallenge() + "\n" );
		_sendButton.addActionListener( new Send() );
	    }
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}	
    }


    /**
     * This handler is used to disconnect from the repository.
     */
    public class Disconnect implements ActionListener
    {
	public void actionPerformed( ActionEvent e )
	{
	    _console.append( "Disconnecting from Repository.\n\n" );

	    _tabbedPane.setEnabledAt( 1, false );
	    _tabbedPane.setEnabledAt( 2, false );
	    _tabbedPane.setEnabledAt( 3, false );

	    try
	    {
		_api.logoff();
	    }
	    catch( Exception ex )
	    {
		ex.printStackTrace();
	    }
	}
    }


    /**
     * This builds the Session tab, and registers all of the handlers.
     *
     * @param tabbedPane the pane containing all four tabs
     * @param api the Shapi object
     */
    public SessionPanel( JTabbedPane tabbedPane, Shapi api )
    {
        super( new BorderLayout() );

	// The credentials area
        _hostField = new JTextField( 10 );
        _hostField.setActionCommand( _hostnameLabel );
        _portField = new JTextField( 10 );
        _portField.setActionCommand( _portLabel );
        
        JLabel hostLabel = new JLabel( _hostnameLabel + ": " );
        hostLabel.setLabelFor( _hostField );
        JLabel portLabel = new JLabel( _portLabel + ": " );
        portLabel.setLabelFor( _portField );

        JPanel textControlsPane = new JPanel();
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        textControlsPane.setLayout( gridbag );

        JLabel[] labels = { hostLabel, portLabel };
        JTextField[] textFields = { _hostField, _portField };
        addLabelTextRows( labels, textFields, gridbag, textControlsPane );

        c.gridwidth = GridBagConstraints.REMAINDER;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = 1.0;

        textControlsPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder("Repository Location"),
	    BorderFactory.createEmptyBorder(10,10,10,10) ));

	// Create the console area
	JPanel consolePane = new JPanel();
	consolePane.setLayout( new BorderLayout() );

	_console = new JTextArea( 
	    "To connect to a SHEMP repository, enter its location " +
	    "above and push the Connect button below.\nOnce connected, " +
	    "this area will display messages from the repository.\nPlease " +
	    "enter your responses in the \"Response\" area below and press " +
	    "Send.\n\n" );

        _console.setLineWrap( true );
        _console.setWrapStyleWord( true );
	_console.setEditable( false );

        JScrollPane areaScrollPane = new JScrollPane( _console );	
        areaScrollPane.setVerticalScrollBarPolicy(
	    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        areaScrollPane.setPreferredSize( new Dimension(190, 190) );

	_responseField = new JPasswordField( 10 );
        JLabel respLabel = new JLabel( "Response: " );
        respLabel.setLabelFor( _responseField );

	_sendButton = new JButton( "Send" );
        _sendButton.setMnemonic( KeyEvent.VK_S );

	consolePane.add( areaScrollPane, BorderLayout.PAGE_START );
	consolePane.add( respLabel, BorderLayout.LINE_START );
	consolePane.add( _responseField, BorderLayout.CENTER );
	consolePane.add( _sendButton, BorderLayout.LINE_END );

        consolePane.setBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Console"),
            BorderFactory.createEmptyBorder(5,5,5,5)),
	    consolePane.getBorder() ));
       
	//Lay out the buttons
        JPanel buttonPane = new JPanel();
	buttonPane.setLayout( new GridLayout(1, 2) );
	buttonPane.setBorder( 
	    BorderFactory.createCompoundBorder( 
	    BorderFactory.createTitledBorder( "" ),
	    BorderFactory.createEmptyBorder(17,10,17,10) ));

	JButton connect = new JButton( "Connect" );
        connect.setMnemonic( KeyEvent.VK_O );
        connect.addActionListener( new Connect() );
	buttonPane.add( connect );

	JButton disconnect = new JButton( "Disconnect" );
        disconnect.setMnemonic( KeyEvent.VK_I );
        disconnect.addActionListener( new Disconnect() );
	buttonPane.add( disconnect );

	add( textControlsPane, BorderLayout.PAGE_START );
	add( consolePane, BorderLayout.CENTER );
	add( buttonPane, BorderLayout.PAGE_END );

	_tabbedPane = tabbedPane;
	_api = api;
    }


    /**
     * A Sun Microsystems function from the SwingAPI demos used
     * to add labels to text fields.
     *
     * @param labels an array of JLabels
     * @param textFields an array of JTextFields to apply the labels to
     * @param gridbag a GridBagLayout to place the fields in
     * @param container the container where everything goes
     */
    private void addLabelTextRows( JLabel[] labels,
                                   JTextField[] textFields,
                                   GridBagLayout gridbag,
                                   Container container )
    {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.EAST;
        int numLabels = labels.length;

        for (int i = 0; i < numLabels; i++)
	{
            c.gridwidth = GridBagConstraints.RELATIVE; //next-to-last
            c.fill = GridBagConstraints.NONE;      //reset to default
            c.weightx = 0.0;                       //reset to default
            container.add( labels[i], c );

            c.gridwidth = GridBagConstraints.REMAINDER;     //end row
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 1.0;
            container.add( textFields[i], c );
        }
    }
}
