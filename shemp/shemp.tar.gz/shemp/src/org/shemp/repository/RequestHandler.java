/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.net.*;
import javax.net.ssl.*;
import javax.security.auth.x500.*;

import org.shemp.common.*;


/**
 * This class is used to handle requests coming from shemp clients.
 */
public class RequestHandler implements ConnectionManager.Handler
{   
    private SSLSocket _socket;


    /**
     * @param sock the socket to fetch the request from
     */
    public void initialize( Socket sock )
    {
	_socket = (SSLSocket) sock;
    }

    
    /**
     * This is the dispatch function which reads a packet
     * from the socket, determines its type, and sends it
     * to the right place for processing.
     */    
    public void execute()
    {
	boolean processing = true;
	String login = "";

	try 
	{	
	    InputStream in = _socket.getInputStream();
	    OutputStream out = _socket.getOutputStream();
	    SSLSession session = _socket.getSession();

	    while (processing == true)
	    {
		// Read the packet
		Packet pkt = PacketComm.recv( in );
		pkt.dump();
		
		// Marshall the request
		if ("UAUTH".compareToIgnoreCase( pkt.getType() ) == 0)
		{
		    PasswdAuthenticator p = new PasswdAuthenticator( in, out );
		    login = p.authenticate( pkt );
		}
		if ("PCREQ".compareToIgnoreCase( pkt.getType() ) == 0)
		{
		    ProxyCertGenerator p = new ProxyCertGenerator( in, out,
								   session );
		    p.generate( pkt, login );
		}
		if ("ECRPT".compareToIgnoreCase( pkt.getType() ) == 0)
		{
		    EncryptionProxy ep = new EncryptionProxy( in, out, 
							      session );
		    ep.encrypt( pkt, login );
		}
		if ("RSIGN".compareToIgnoreCase( pkt.getType() ) == 0)
		{
		    SigningProxy sp = new SigningProxy( in, out, session );
		    sp.sign( pkt, login );
		}
		if ("LOGOF".compareToIgnoreCase( pkt.getType() ) == 0)
		{
		    in.close();
		    out.close();
		    _socket.close();
		    
		    processing = false;
		}		
	    }
	}
	catch( Exception e )
	{
	    e.printStackTrace();

	    try
	    {
		_socket.close();
	    }
	    catch( Exception e2 ) {}
	}
    }
}
