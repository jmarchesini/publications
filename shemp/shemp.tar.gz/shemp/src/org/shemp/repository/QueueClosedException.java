/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.util.*;


public class QueueClosedException extends RuntimeException
{
    public QueueClosedException()
    {
	super( "The Queue is closed for business." );
    }
}
