/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import java.io.*;
import java.net.*;
import java.math.*;
import java.security.*;
import java.security.cert.*;

import javax.security.auth.x500.*;


/**
 * This is an abstract class which holds the data and operations
 * common to all SHEMP attribute certificates---RAC, PAC, and KUP.
 */
abstract class Populator
{
    /**
     * Get the cert for the issuer and verify the envelope signature.
     *
     * @param msg the message to verify
     * @param sig the signature
     * @param dir the directory containing the certificates
     * @param issuerDN the DN of the attribute's issuer
     * @return true if the signature verifies, false otherwise
     * @throws Exception if there are problems
     */
    protected boolean verifyAttribute( String msg, String sig, String dir, 
				       String issuerDN ) throws Exception
    {
	// The envelope -- strip the XML comments and whitespace
	msg = msg.replaceAll( "<!--.*?-->", "" );
	msg = msg.replaceAll( " ", "" );
	byte [] msgbytes = msg.getBytes();

	// Get the signature
	BigInteger bint = new BigInteger( sig, 16 );
	byte [] sigbytes = bint.toByteArray();

	// Extract the CN and Get the cert
	String cn = KeyUtil.getCN( issuerDN );
	X509Certificate cert = getCertificate( dir + "/" + cn + "cert.pem" );

	// Verify
	Signature s = Signature.getInstance( "SHA1withRSA" );
	s.initVerify( cert );
	s.update( msgbytes );

	return s.verify( sigbytes );
    }


    /**
     * Get the subject from the certificate belonging to the login.
     *
     * @param certname the pathname to the certificate
     * @return the subject's X500 name from their cert as a String
     */
    protected String getSubject( String certname ) throws Exception
    {
	X509Certificate cert = getCertificate( certname );
	X500Principal subject = cert.getSubjectX500Principal();

	return subject.getName();
    }


    /**
     * This will get scrapped once we plug into the prototype.
     *
     * @param certname the pathname to the certificate
     * @return the certificate
     */
    private X509Certificate getCertificate( String certname ) throws Exception
    {
	String certstr = FileUtil.read( certname );
	certstr = KeyUtil.prettyPrintCerts( certstr );

	return KeyUtil.getCertificate( certstr );
    }
}
