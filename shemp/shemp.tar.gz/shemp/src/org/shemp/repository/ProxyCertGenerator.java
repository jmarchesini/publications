/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import com.sun.xacml.ctx.RequestCtx;

import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.*;
import java.security.interfaces.*;
import java.math.BigInteger;

import javax.net.*;
import javax.net.ssl.*;
import javax.security.auth.x500.*;

import org.globus.gsi.*;
import org.globus.gsi.bc.*;
import org.globus.gsi.proxy.ext.*;

import org.bouncycastle.jce.X509V3CertificateGenerator;
import org.bouncycastle.jce.PKCS10CertificationRequest;
import org.bouncycastle.jce.provider.X509CertificateObject;
import org.bouncycastle.asn1.DERConstructedSequence;
import org.bouncycastle.asn1.DERConstructedSet;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.asn1.DERInputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.KeyUsage;


/**
 * This class is used to generate Proxy Certificates.
 */
public class ProxyCertGenerator
{
    private InputStream _in = null;
    private OutputStream _out = null;
    private SSLSession _session = null;

    /**
     * Sets up a new ProxyCertGenerator.
     *
     * @param in the InputStream to the client
     * @param out the OutputStream to the client
     * @param session the SSLSession for this connection
     */
    public ProxyCertGenerator( InputStream in, OutputStream out, 
			       SSLSession session )
    {
	_in = in;
	_out = out;
	_session = session;
    }


    /**
     * The public method to generate a new request.
     *
     * @param pkt the Packet object from the socket
     * @param login the username to mint a proxy cert for 
     */
    public void generate( Packet pkt, String login ) throws Exception
    {
	String tempkey = pkt.getPayload();
	PublicKey pubkey = translatePubKey( tempkey );
	String password = ConfigOptions.instance().getUserPword();
	KeyStore kstore = KeyUtil.loadKeystore( 
	    ConfigOptions.instance().getUserstore(), password );

	// Do the policy check
	PolicyEngine pe = new PolicyEngine( login, _session );
	RequestCtx request = pe.generateRequest( "generate" );
	boolean allowed = pe.isAllowed( request );

	if (allowed == false)
	{
	    Packet reply = new Packet( "PCREQ", "POLICY_FAIL" );
	    PacketComm.send( reply, _out );
	}
	else
	{
	    // Load the user's cert & private key
	    KeyStore.PasswordProtection pp = 
		new KeyStore.PasswordProtection( password.toCharArray() );
	    KeyStore.PrivateKeyEntry pke = 
		(KeyStore.PrivateKeyEntry) kstore.getEntry( login, pp );

	    PrivateKey privkey = pke.getPrivateKey();
	    X509Certificate crt = 
		(X509Certificate) kstore.getCertificate( login );

	    // Make the PCI extension and generate the PC
	    DERObjectIdentifier oid = 
		new DERObjectIdentifier( "1.3.6.1.4.1.65.2.2.1" );
	    ProxyPolicy policy = new ProxyPolicy( oid, pe.getPolicy() );
	    ProxyCertInfo pci = new ProxyCertInfo( policy );

	    X509Certificate pc = 
		createPC( crt, privkey, pubkey, 7200,
			  GSIConstants.GSI_3_LIMITED_PROXY,
			  pci, "SHEMP Proxy Certificate" );

	    // Dump the PC
	    KeyUtil.dumpPC( pc );

	    // Get the encoded version to Base64
	    BASE64Encoder b64e = new BASE64Encoder();
	    String der = b64e.encode( pc.getEncoded() );
	    String base64cert = "-----BEGIN CERTIFICATE-----\n" + der +
		"\n-----END CERTIFICATE-----\n";

	    // Send it back
	    Packet reply = new Packet( "PCREQ", base64cert );
	    PacketComm.send( reply, _out );
	}
    }


    /**
     * Translate encoded public keys into Java PublicKeys.
     *
     * @param pk the String version of the public key PEM encoded
     * @return the PublicKey
     * @throws Exception if something bad happens
     */
    private PublicKey translatePubKey( String pk ) throws Exception
    {
	// Strip -----BEGIN/END PUBLIC KEY-----
	pk = pk.replaceAll( "-----.*?-----", "" );

	// Build a PublicKey for the tempkey
	BASE64Decoder b64d = new BASE64Decoder();
	byte [] keybytes = b64d.decodeBuffer( pk );
	KeyFactory kf = KeyFactory.getInstance( "RSA" );
	KeySpec kspec = new X509EncodedKeySpec( keybytes );

	return kf.generatePublic( kspec );
    }


    /**
     * Private method to generate a PC.  The one in the COG toolkit
     * is deprecated in Java 1.5, so I adapted theirs.
     *
     * @param issuerCert the certificate belonging to the issuer
     * @param issuerKey the PrivateKey of the issuer
     * @param publicKey the PublicKey to put in the PC
     * @param lifetime the lifetime of the cert in seconds
     * @param proxyType the type of this proxy certificate
     * @param proxyCertInfo the data to get stuffed in the PCI
     * @param cnValue the CN to append to the CN of the issuer's cert
     * @return the Proxy X509Certificate
     * @throws GeneralSecurityException if the cert can't be minted
     */
    private X509Certificate createPC( X509Certificate issuerCert, 
				      PrivateKey issuerKey,
				      PublicKey publicKey,
				      int lifetime,
				      int proxyType,
				      ProxyCertInfo proxyCertInfo,
				      String cnValue ) 
	throws GeneralSecurityException 
    {	
	if (proxyType == GSIConstants.DELEGATION_LIMITED)
	{
	    proxyType = (CertUtil.isGsi3Enabled()) ? 
		GSIConstants.GSI_3_LIMITED_PROXY :
		GSIConstants.GSI_2_LIMITED_PROXY;
	} 
	else if (proxyType == GSIConstants.DELEGATION_FULL)
	{
	    proxyType = (CertUtil.isGsi3Enabled()) ? 
		GSIConstants.GSI_3_IMPERSONATION_PROXY :
		GSIConstants.GSI_2_PROXY;
	}

	X509V3CertificateGenerator certGen = new X509V3CertificateGenerator();

	BigInteger serialNum = null;
	String delegDN = null;
	
	if (CertUtil.isGsi3Proxy( proxyType ))
	{
	    Random rand = new Random();
	    delegDN = String.valueOf(Math.abs(rand.nextInt()));
	    serialNum = new BigInteger(20, rand);
	    
	    // add ProxyCertInfo extension
	    if (proxyCertInfo == null)
	    {
		ProxyPolicy policy = null;

		if (proxyType == GSIConstants.GSI_3_IMPERSONATION_PROXY)
		{
		    policy = new ProxyPolicy( ProxyPolicy.IMPERSONATION );
		} 
		else if (proxyType == GSIConstants.GSI_3_INDEPENDENT_PROXY)
		{
		    policy = new ProxyPolicy( ProxyPolicy.INDEPENDENT );
		}
		else if (proxyType == GSIConstants.GSI_3_LIMITED_PROXY)
		{
		    policy = new ProxyPolicy( ProxyPolicy.LIMITED );
		}
		else if (proxyType == GSIConstants.GSI_3_RESTRICTED_PROXY)
		{
		    throw new IllegalArgumentException( "Restricted proxy " +
							"requires PCI" );
		} 
		else
		{
		    throw new IllegalArgumentException( "Invalid proxyType" );
		}

		proxyCertInfo = new ProxyCertInfo( policy );
	    }

	    certGen.addExtension( ProxyCertInfo.OID, true, proxyCertInfo );

	    try
	    {
		TBSCertificateStructure crt = 
		    BouncyCastleUtil.getTBSCertificateStructure( issuerCert );
		X509Extensions extensions = crt.getExtensions();

		if (extensions != null)
		{
		    X509Extension ext;
		    
		    // handle key usage ext
		    ext = extensions.getExtension( X509Extensions.KeyUsage );
		    
		    if (ext != null)
		    {
			DERBitString bits = (DERBitString)
			    BouncyCastleUtil.getExtensionObject( ext );
			byte [] bytes = bits.getBytes();

			// make sure they are disabled
			if ((bytes[0] & KeyUsage.nonRepudiation) != 0)
			{
			    bytes[0] ^= KeyUsage.nonRepudiation;
			}

			if ((bytes[0] & KeyUsage.keyCertSign) != 0)
			{
			    bytes[0] ^= KeyUsage.keyCertSign;
			}

			bits = new DERBitString( bytes, bits.getPadBits() );

			certGen.addExtension( X509Extensions.KeyUsage,
					      ext.isCritical(),
					      bits );
		    }
		}

	    }
	    catch( IOException e )
	    {
		// but this should not happen
		throw new GeneralSecurityException( e.getMessage() );
	    }
	    
	}
	else if (proxyType == GSIConstants.GSI_2_LIMITED_PROXY)
        {
	    delegDN = "limited proxy";
	    serialNum = issuerCert.getSerialNumber();
	}
	else if (proxyType == GSIConstants.GSI_2_PROXY)
	{
	    delegDN = "proxy";
	    serialNum = issuerCert.getSerialNumber();
	}
	else
        {
	    throw new IllegalArgumentException( "Unsupported proxyType : " +
						proxyType );
	}

	// Shim code to translate the JDK 1.5 certificate datastructs.
	X500Principal issuerX500 = issuerCert.getSubjectX500Principal();
	X509Name issuerDN= new X509Name( issuerX500.getName() );
	X509NameHelper issuer  = new X509NameHelper( issuerDN );
	X509NameHelper subject = new X509NameHelper( issuerDN );
 
	subject.add( X509Name.CN, (cnValue == null) ? delegDN : cnValue );
	
	certGen.setSubjectDN( subject.getAsName() );
        certGen.setIssuerDN( issuer.getAsName() );
        certGen.setSerialNumber( serialNum );
        certGen.setPublicKey( publicKey );
        certGen.setSignatureAlgorithm( issuerCert.getSigAlgName() );

	GregorianCalendar date =
	    new GregorianCalendar( TimeZone.getTimeZone("GMT") );

	/* Allow for a five minute clock skew here. */
	date.add( Calendar.MINUTE, -5 );
	certGen.setNotBefore( date.getTime() );

        /* If hours = 0, then cert lifetime is set to user cert */
        if (lifetime <= 0)
	{
            certGen.setNotAfter( issuerCert.getNotAfter() );
        }
	else
	{
	    date.add( Calendar.MINUTE, 5 );
	    date.add( Calendar.SECOND, lifetime );
            certGen.setNotAfter( date.getTime() );
        }
	
	/**
	 * FIXME: Copy appropriate cert extensions - this should NOT be done
	 * the last time we talked to Doug E. This should investigated more.
	 */

	return certGen.generateX509Certificate( issuerKey );
    }
}
