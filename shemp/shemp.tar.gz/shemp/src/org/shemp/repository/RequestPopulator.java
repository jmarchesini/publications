/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import java.io.*;
import java.net.*;
import java.math.*;
import java.security.*;
import java.security.cert.*;

import javax.security.auth.x500.*;


/**
 * This class is used to get data from different sources and populate
 * a RequestDataObj which holds the information.  This class is repsonsible
 * for constructing a well-formed RequestDataObj.  The requestor and
 * desired operation are given to the constructor.  The RequestPopulator
 * then finds all applicable attribute certs, and for each one, verifies
 * the signature and places the data into the RequestDataObj.
 */
public class RequestPopulator extends Populator
{
    private String _login;
    private String _action;
    private String _dir;
    private String _repCN;
    private String _pltCN;
    
    private RequestDataObj _rdo;


    /**
     * The constuctor takes the static infomation, and the <code>popluate</code>
     * method does the rest.
     *
     * @param login the login of the user making the request
     * @param action the action being requested in {generate,decrypt,sign}
     * @param dir the location of all the certs
     * @param repCN the repository's CN
     * @param pltCN the platform's CN
     */
    public RequestPopulator( String login, String action, String dir,
			     String repCN, String pltCN )
    {
	_login = login;
	_action = action;
	_dir = dir;
	_repCN = repCN;
	_pltCN = pltCN;

	_rdo = new RequestDataObj();
    }

    
    /**
     * This is the hook that clients use to get the data and
     * put it in the RequestDataObj.  It goes through the directory,
     * looking for all of the attribute certs which apply to the
     * current connection.  For each cert, it verifies the envelope
     * signature, and then allows the parser to fill the values from
     * the cert into the RequestDataObj.  Once the RequestDataObj
     * has been filled out, it is returned to the client.
     *
     * @return the populated RequestDataObj holding all of the request info
     */
    public RequestDataObj populate() throws Exception
    {
 	_rdo.addSubject( getSubject(_dir + "/" + _login + "cert.pem") );
	_rdo.addResource( "PrivateKey" );
	_rdo.addAction( _action );

	String repcert = _dir + "/" + _repCN + "attr.xml";
	String pltcert = _dir + "/" + _pltCN + "attr.xml";

	AttributeCertHandler rhndlr = new AttributeCertHandler( repcert, _rdo );
	AttributeCertHandler phndlr = new AttributeCertHandler( pltcert, _rdo );

	boolean repverified = verifyAttribute( rhndlr.getEnvelopeAsStr(),
					       rhndlr.getEnvelopeSigAsStr(),
					       _dir,
					       rhndlr.getIssuerDN() );
	boolean pltverified = verifyAttribute( phndlr.getEnvelopeAsStr(),
					       phndlr.getEnvelopeSigAsStr(),
					       _dir,
					       phndlr.getIssuerDN() );

	if (repverified == true && pltverified == true)
	{
	    SaxParserDriver rparser = new SaxParserDriver( 
		rhndlr.getFileAsStr(), rhndlr );
	    SaxParserDriver pparser = new SaxParserDriver( 
		phndlr.getFileAsStr(), phndlr );
	}

	return _rdo;
    }
}
