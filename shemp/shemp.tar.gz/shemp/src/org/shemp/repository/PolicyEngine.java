/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import com.sun.xacml.*;
import com.sun.xacml.attr.*;
import com.sun.xacml.ctx.*;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.net.*;
import javax.net.ssl.*;
import javax.security.auth.x500.X500Principal;


/**
 * This is the hook to the embedded PEP/PDP subsystem.  This class formulates an
 * XACML request based on the parameters passed in.  It parses all of the
 * necessary attribute certificates, verifies them, and constructs the request.
 * It can then be used to send the well formed request to the PDP to
 * determine whether the action should be allowed.
 */
public class PolicyEngine
{
    private String _login = null;
    private String _localDN = null;
    private String _peerDN = null;
    private String _request = null;
    private String _xacml = null;

    private SSLSession _session = null;


    /**
     * The constructor takes the basic inputs used in the request.
     * 
     * @param login the login name of the user as a String
     * @param session the current SSL session
     * @throws SSLPeerUnverifiedException if the SSL connection isn't good
     */
    public PolicyEngine( String login, SSLSession session ) 
	throws SSLPeerUnverifiedException
    {
	_login = login;
	_session = session;

	X500Principal local = (X500Principal) session.getLocalPrincipal();
	X500Principal peer = (X500Principal) session.getPeerPrincipal();

	_localDN = local.getName();
	_peerDN = peer.getName();

	_request = "";
	_xacml = "";
    }


    /**
     * This method actually generates a well-formed XACML request based
     * on the action, state information given to the constructor, and 
     * the environment found in the attribute certificates.
     *
     * @param action the action the user is requesting {generate,decrypt,sign}
     * @return request context object holding the XACML request
     * @throws Exception if the parsing goes wrong
     */
    public RequestCtx generateRequest( String action ) throws Exception
    {
	ByteArrayOutputStream out = new ByteArrayOutputStream();

	String certdir = ConfigOptions.instance().getCertDir();
	String repCN = KeyUtil.getCN( _localDN );
	String pltCN = KeyUtil.getCN( _peerDN );

	RequestPopulator pop = new RequestPopulator( _login, action, certdir,
						     repCN, pltCN );
	RequestDataObj rdo = pop.populate();

	RequestCtx request = new RequestCtx( rdo.getSubject(),
					     rdo.getResource(),
					     rdo.getAction(),
					     rdo.getEnvironment() );
        
	request.encode( out );

	_request = out.toString();
	_request = _request.replaceAll( "\n", "" );

	System.out.println( "\n============================================" );
	System.out.println( _request );
	System.out.println( "============================================" );

	return request;
    }


    /**
     * This method decides whether the request is valid or not.  It
     * gets the user's policy, verifies the signature, and then uses
     * an embedded XACML PDP to decide whether the request should be
     * allowed or not.
     *
     * @param request the XACML request to check
     * @return true if the request is allowed, false otherwise
     */
    public boolean isAllowed( RequestCtx request )
    {
	String filename = "/tmp/policy.xml";

	try
	{
	    String certdir = ConfigOptions.instance().getCertDir();
	    KupPopulator pop = new KupPopulator( _login, certdir );
	    String xacml = pop.populate();

	    if (xacml != null)
	    {
		_xacml = xacml;

		System.out.println( "\n=====================================" +
				    "=======\n" );
		System.out.println( _xacml );
		System.out.println( "=======================================" +
				    "=====\n" );

		File file = dumpToFile( filename, xacml );
		PolicyDecider pd = new PolicyDecider( filename );
		ResponseCtx response = pd.evaluate( request );
		
		file.delete();

		return decodeResponse( response );
	    }
	    
	    return false;
	}
	catch( Exception e )
	{
	    e.printStackTrace();
	    return false;
	}
    }


    /**
     * This method returns a String containing an xml fragment which
     * gets stuffed into the PC's PCI extension.  The fragment contains
     * the request and the user's XACML policy.  The policy is defined
     * by Dartmouth OID 1.3.6.1.4.1.65.2.2.2 and a DTD is available at
     * http://www.dartmouth.edu/~pkilab/pages/DartmouthOID.html
     *
     * @return the policy as a String 
     */
    public String getPolicy()
    {
	return "\n<shempPCI>\n" + _request + "\n" + _xacml + "\n</shempPCI>\n";
    }


    /**
     * This method takes an XACML ResponseCtx and generated a boolean
     * response which is the answer.  The mapping is as follows:
     *
     * Permit --> true; {Deny,Indeterminate,NotApplicable} --> false
     *
     * @param reponse the XAMCL response from the PDP
     * @return true if PDP responded 'Permit', false otherwise
     */
    private boolean decodeResponse( ResponseCtx response )
    {
	Set resultSet = response.getResults();
	Iterator i = resultSet.iterator();
	
	while (i.hasNext() == true)
	{
	    Result res = (Result) i.next();

	    if (res.getDecision() != Result.DECISION_PERMIT)
	    {
		return false;
	    }
	}

	return true;
    }


    /**
     * A small helper that builds a temp file to store the policy in.
     *
     * @param filename the filename to dump the policy to
     * @param xacml the policy to put in the file
     * @return the File object
     * @throws IOException if the file can't be created or written to
     */
    private File dumpToFile( String filename, String xacml ) throws IOException
    {
	File file = new File( filename );

	if (file.exists() == true)
	{
	    file.delete();
	}
	
	file.createNewFile();

	PrintStream out = new PrintStream( new FileOutputStream(file, false) );

	out.print( xacml );
	out.flush();
	out.close();

	return file;
    }
}
