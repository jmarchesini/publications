/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import java.io.*;
import java.net.*;
import java.lang.*;
import java.util.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;


/**
 * This is the core of the attribute certificate parser.
 * It is a standard SAX parser is used to parse the attribute
 * certificates and fill out the RequestDataObj.
 */
public class AttributeCertHandler extends DefaultHandler
{
    private String _currentElement = null;
    private String _certFile = "";
    private String _envelope = "";
    private String _envelopeSig = "";
    private String _subject = "";
    private String _issuer = "";
    private String _key = "";
    private String _value = "";

    private RequestDataObj _rdo = null;


    /**
     * The constructor reads the certfile, stores off a copy of the 
     * envelope, and gets ready to parse.
     *
     * @param certfile a pathname to the attribute certificate file
     * @throws IOException if the file cannot be opened
     */
    public AttributeCertHandler( String certfile ) throws IOException
    {
	_certFile = FileUtil.read( certfile );

	int begin = _certFile.indexOf( "<envelope>" );
	int end = _certFile.lastIndexOf( "</envelope>" ) +
	    "</envelope>".length();
	_envelope = _certFile.substring( begin, end );

	begin = _certFile.indexOf( "<envelopeSignature>" ) + 
	    "<envelopeSignature>".length();
	end = _certFile.lastIndexOf( "</envelopeSignature>" );
	_envelopeSig = _certFile.substring( begin, end );

	begin = _certFile.indexOf( "<issuerDN>" ) + "<issuerDN>".length();
	end = _certFile.lastIndexOf( "</issuerDN>" );
	_issuer = _certFile.substring( begin, end );

	begin = _certFile.indexOf( "<subjectDN>" ) + "<subjectDN>".length();
	end = _certFile.lastIndexOf( "</subjectDN>" );
	_subject = _certFile.substring( begin, end );
    }


    /**
     * The constructor reads the certfile, stores off a copy of the 
     * envelope, and gets ready to parse.
     *
     * @param certfile a pathname to the attribute certificate file
     * @param rdo a RequestDataObject to fill out
     * @throws IOException if the file cannot be opened
     */
    public AttributeCertHandler( String certfile, RequestDataObj rdo )
	throws IOException
    {
	this( certfile );
 
	_rdo = rdo;
    }


    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     */
    public void startDocument() throws SAXException {}


    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *    
     * @throws SAXException if a parse error occurs
     */    
    public void endDocument() throws SAXException {}

    
    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void startElement( String uri, String localName,
			      String qName, Attributes attributes )
        throws SAXException 
    {
	_currentElement = qName;
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void endElement( String uri, String localName, String qName )
        throws SAXException
    {
	if ("attribute".equals(qName))
        {
	    try
	    {
		_rdo.addEnvironment( _key, _value, _issuer );
	    }
	    catch( URISyntaxException e )
	    {
		e.printStackTrace();
	    }
	    
	    _key = "";
	    _value = "";
        }
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void characters( char[] ch, int start, int length )
        throws SAXException
    {
	if ("attribute".equals(_currentElement))
	{
	    String attr = new String( ch, start, length);
	    String[] pair = attr.split( "=" );

	    _key = pair[0];
	    _value = pair[1];
	}
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void error( SAXParseException e )
        throws SAXException
    {
        e.printStackTrace();
    }


    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */    
    public void fatalError( SAXParseException e )
        throws SAXException
    {
        e.printStackTrace();
    }
    

    /**
     * This method customized the DefaultHandler interface for the
     * certfile format.
     *
     * @throws SAXException if a parse error occurs
     * @see org.xml.sax.helpers.DefaultHandler
     */
    public void warning( SAXParseException e )
        throws SAXException
    {
        e.printStackTrace();
    }


    /**
     * This method returns the unparsed attribute certificate as a String.
     *
     * @return the unparsed attribute certificate as a String
     */
    public String getFileAsStr()
    {
	return _certFile;
    }


    /**
     * This method returns the envelope as a String.
     *
     * @return the unparsed enveloper as a String
     */
    public String getEnvelopeAsStr()
    {
	return _envelope;
    }


    /**
     * This method returns the envelope signature as a String of hex bytes.
     *
     * @return the signature as a String of hex bytes
     */
    public String getEnvelopeSigAsStr()
    {
	return _envelopeSig;
    }


    /**
     * This method returns the IssuerDN of the attribute certificate.
     *
     * @return the issuerDN as a String
     */
    public String getIssuerDN()
    {
	return _issuer;
    }


    /**
     * This method returns the subjectDN of the attribute certificate.
     *
     * @return the subjectDN as a String
     */
    public String getSubjectDN()
    {
	return _subject;
    }
}
