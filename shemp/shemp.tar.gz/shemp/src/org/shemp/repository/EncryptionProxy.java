/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import com.sun.xacml.ctx.RequestCtx;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.interfaces.*;

import javax.crypto.*;
import javax.net.*;
import javax.net.ssl.*;


/**
 * This class is used to decrypt messages which were encrypted with
 * a user's long-term public key (the private portion lives on the
 * repository).  Once the decrytion is complete, a policy check occurs
 * and if successful, the plaintext is encrypted with the user's PC
 * public key and returned.
 */
public class EncryptionProxy
{
    private InputStream _in = null;
    private OutputStream _out = null;
    private SSLSession _session = null;


    /**
     * Sets up a new EncryptionProxy
     *
     * @param in the InputStream to the client
     * @param out the OutputStream to the client
     * @param session the SSLSession for this connection
     */
    public EncryptionProxy( InputStream in, OutputStream out,
			    SSLSession session )
    {
	_in = in;
	_out = out;
	_session = session;
    }


    /**
     * The public method to encrypt.
     *
     * @param pkt the Packet object from the socket
     * @param login the username to mint a proxy cert for 
     */
    public void encrypt( Packet pkt, String login ) throws Exception
    {
	String pempc = pkt.getPayload();

        // Do the policy check
	PolicyEngine pe = new PolicyEngine( login, _session );
	RequestCtx request = pe.generateRequest( "encrypt" );
	boolean allowed = pe.isAllowed( request );

	if (allowed == false)
	{
	    Packet reply = new Packet( "ECRPT", "POLICY_FAIL" );
	    PacketComm.send( reply, _out );
	}
	else
	{
	    // Send a continue to get the message
	    Packet cont = new Packet( "ECRPT", "CONTINUE" );
	    PacketComm.send( cont, _out );

	    Packet cipherpkt = PacketComm.recv( _in );
	    String cipher64 = cipherpkt.getPayload();

	    String plaintext = decrypt( cipher64, login );
	    String result = reencrypt( pempc, plaintext );

	    // Return the new ciphertext
	    Packet reply = new Packet( "ECRPT", result );
	    PacketComm.send( reply, _out );
	}
    }


    /**
     * This method decrypts ciphertext with alias's private key.
     * Note that the ciphertext should be in base64.
     */
    private String decrypt( String ciphertext, String alias ) throws Exception
    {
	// Decode the ciphertext
	BASE64Decoder b64 = new BASE64Decoder();
	byte [] encbytes = b64.decodeBuffer( ciphertext );

	// Load the keystore
	KeyStore ks = KeyUtil.loadKeystore( 
	    ConfigOptions.instance().getUserstore(),
	    ConfigOptions.instance().getUserPword() );

	// Get the private key and decrypt
	String pw = ConfigOptions.instance().getUserPword();
	Key key = ks.getKey( alias, pw.toCharArray() );
	Cipher c = Cipher.getInstance( "RSA" );

	c.init( Cipher.DECRYPT_MODE, key );

	byte[] cleartext = c.doFinal( encbytes );

	return new String( cleartext );
    }


    /**
     * This method is used to encrypt the msg with the key found in the
     * PC.  The result is returned.
     */
    private String reencrypt( String pc, String msg ) throws Exception
    {
	pc = KeyUtil.prettyPrintCerts( pc );
	X509Certificate cert = KeyUtil.getCertificate( pc );

	Cipher c = Cipher.getInstance( "RSA" );
	c.init( Cipher.ENCRYPT_MODE, cert );
	
	BASE64Encoder b64 = new BASE64Encoder();
	String cipher64 = b64.encode( c.doFinal(msg.getBytes()) );

	System.out.println( "\n============================================" );
	System.out.println( "Encrypting message:\n" + msg );
	System.out.println( "\nResult:\n" + cipher64 );
	System.out.println( "============================================" );

	return cipher64;
    }
}
