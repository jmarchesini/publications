/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import java.util.*;


/**
 * A generic thread pool used to execute requests.
 */
public class ThreadPool extends ThreadGroup
{
    private JobQueue _pool = new JobQueue();
    private boolean _closed = false;

    private int _max_size;
    private int _pool_size;

    private static int _group = 0;
    private static int _thread_id = 0;


    /**
     * Construct the pool with the initial number of threads
     * to be run and the maximum size to grow to.
     *
     * @param initial_num_threads the initial number of threads
     * @param max_num_threads the maximum number of threads
     */
    public ThreadPool( int initial_num_threads, int max_num_threads )
    {
	super( "ThreadPool" + _group++ );

	_max_size = max_num_threads;
	_pool_size = initial_num_threads;

	for (int idx = _pool_size - 1; idx >= 0; idx--)
	{
	    new WorkerThread().start();
	}
    }


    /**
     * This is the client interface to submit a job to the pool.
     *
     * @param job the job to execute
     * @throws QueueClosedException if the JobQueue is closed
     */
    public synchronized void execute( Runnable job )
	throws QueueClosedException
    {
	if (_closed)
	{
	    throw new QueueClosedException();
	}

	if (_pool_size < _max_size)
	{
	    // Fixes very brief race condition between
	    //  checking for size and starting thread.
	    synchronized( _pool )
	    {
		if (_pool.isEmpty())
		{
		    ++_pool_size;
		    new WorkerThread().start();
		}
	    }
	}
	
	_pool.enqueue( job );
    }


    /**
     * Client interface to shutdown.
     */
    public synchronized void shutdown()
    {
	_closed = true;
	_pool.shutdown();
    }


    /**
     * WorkerThreads get jobs off the queue and run them.
     */
    private class WorkerThread extends Thread
    {  
        public WorkerThread()
        {
	    super( ThreadPool.this, ("Thread:" + _thread_id) );
        }


	/**
	 * Get a job and call it's run method.
	 */
        public void run()
        {   
	    try
            {
		while (!_closed)
                {
		    ((Runnable)( _pool.dequeue() )).run();
                }
            }
            catch( InterruptedException e ){}
            catch( QueueClosedException e ){}
        }
    }
    
}
