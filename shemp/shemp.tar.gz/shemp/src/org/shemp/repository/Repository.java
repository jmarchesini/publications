/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.repository;

import org.shemp.common.*;

import java.lang.*;
import java.io.*;
import java.net.*;

import java.security.*;
import java.security.cert.*;

import javax.net.*;
import javax.net.ssl.*;


/**
 * This is the main for the repository.
 */
public class Repository
{
    /**
     * Main method to parse command line args, set up the socket,
     * read the keystore, and begin listening for requests.
     */
    public static void main( String args[] )
    {	
	String conffile = "";

	if (args.length != 1)
	{
	    System.out.println( 
		"USAGE: java Repository conffile" );
	    System.exit( -1 );
	}
	else 
	{
	    conffile = args[0];
	}

	// Parse Config File and populate ConfigOptions
	ConfigOptions co = ConfigOptions.instance();

	try
	{
	    ConfFileHandler handler = new ConfFileHandler( conffile );
	    SaxParserDriver parser = new SaxParserDriver( 
					    handler.getFileAsStr(), handler );
	}
	catch( Exception e )
	{
	    System.err.println( "Unable to parse configuration file.  " +
				"Shutting down. ");
	    System.exit( -1 );
	}

	// Start subsystems
	String keystore = co.getKeystore();
	String password = co.getPassword();
	String logfile = co.getLogfile();
	int threads = co.getThreads();
	int port = co.getPort();

	setupLogger( logfile );
	setupServer( port, threads, keystore, password );
    }


    /**
     * Sets the streams to point to logs instead of STDOUT.  The
     * repository will not start if the logger cannot be started.
     *
     * @param logfile the path to the logfile
     */
    private static void setupLogger( String logfile )
    {
	try
	{
	    File f = new File( logfile );

	    if (!f.exists())
	    {
		f.createNewFile();
	    }
		    
	    PrintStream out = new PrintStream( new FileOutputStream(f, true) );

	    System.setOut( out );
	    System.setErr( out );
	}
	catch( Exception e )
	{
	    System.err.println( "Unable to log to: " + logfile );
	    System.err.println( "Shutting down." );
	    System.exit( -1 );
	}
    }


    /**
     * Gets the server infrastructure up and running.
     *
     * @param port the port to listen for other slave requests on
     * @param numthreads initial number of threads to spawn
     * @param keystore the keystore to use
     * @param password the password for the keystore
     */
    private static void setupServer( int port, int numthreads, 
				     String keystore, String password )
    {
	ConnectionManager mgr;
	SSLServerSocket sock;

	try
	{
	    SSLContext ctx = KeyUtil.getSSLContext( keystore, password );
	    SSLServerSocketFactory factory = ctx.getServerSocketFactory();
	    
	    sock = (SSLServerSocket)factory.createServerSocket( port );
	    sock.setNeedClientAuth( true );
	}
	catch( Exception e ) 
	{
	    throw new Error( "Unable to open socket:" + e.getMessage() );
	}

	mgr = new ConnectionManager( sock, numthreads, RequestHandler.class );
	
	try
	{
	    mgr.start();
	}
	catch( Exception e ) 
	{
	    System.out.println( "Unable to start ConnectionManager" + 
				e.getMessage() );
	    mgr.shutdown();
	    System.exit( -1 );
	}
    }
}

