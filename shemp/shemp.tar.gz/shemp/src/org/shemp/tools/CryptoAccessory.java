/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.tools;

import org.shemp.common.*;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.*;
import java.security.interfaces.*;

import javax.crypto.*;
import javax.security.auth.x500.*;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;


/**
 * This is a little utility which performs the basic crypto
 * primitives of en/decrypting, signing, and verifying.  This came
 * in handy on may occasions---especially when I had to figure
 * out the Java 1.5 way of implementing a number of the operations
 * for inclusion in the repository.  It does RSA operations on data
 * directly, which is not how it's done in the "real world", but who
 * cares.
 */
public class CryptoAccessory
{
    private static boolean TIMING = false;


    /**
     * This is main; it takes one optional param to turn on the
     * timing.
     *
     * @param args the optional arguments to main: 'true' to enable timing
     */
    public static void main( String args[] )
    {
	if (args.length == 1 && args[0].compareToIgnoreCase("true") == 0)
	{
	    TIMING = true;
	}

	BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
	String choice = "";

	try
	{
	    while (true)
	    {
		System.out.println( "\n\n===================================" );
		System.out.println( "* Welcome to the Crypto Accessory *" );
		System.out.println( "===================================" );
		System.out.println( "\nWould you like to:" );
		System.out.println( "E)ncrypt a message for someone" );
		System.out.println( "D)ecrypt a message with your priv. key" );
		System.out.println( "S)ign a message with your priv. key" );
		System.out.println( "V)erify a signature" );
		System.out.println( "Q)uit" );
		System.out.print( "\n[e/d/s/v/q] => " );

		choice = b.readLine();

		if (choice.compareToIgnoreCase("e") == 0)
		{
		    System.out.print( "\n\nFile containing the cert. => " );
		    String infile = b.readLine();

		    System.out.print( "File to dump the result => " );
		    String outfile = b.readLine();

		    System.out.print( "File containing message => " );
		    String msgfile = b.readLine();

		    String ciphertext = encrypt( infile, msgfile, outfile );
		    System.out.println( "\nWrote ciphertext to: " + outfile );
		}
		else if (choice.compareToIgnoreCase("d") == 0)
		{
		    System.out.print( "\n\nFile containing ciphertext => " );
		    String infile = b.readLine();

		    System.out.print( "Keystore alias (login) => " );
		    String alias = b.readLine();
		    
		    String cleartext = decrypt( infile, alias, b );
		    System.out.println( "\nDecrypted message: " + cleartext );
		}
		else if (choice.compareToIgnoreCase("s") == 0)
		{
		    System.out.print( "\n\nFile containing message => " );
		    String msgfile = b.readLine();

		    System.out.print( "File to dump the result => " );
		    String outfile = b.readLine();

		    System.out.print( "Keystore alias (login) => " );
		    String alias = b.readLine();

		    String digest = sign( msgfile, outfile, alias, b );
		    System.out.println( "\nSignature:\n" + digest );
		}
		else if (choice.compareToIgnoreCase("v") == 0)
		{
		    System.out.print( "\n\nFile containing message => " );
		    String msgfile = b.readLine();

		    System.out.print( "File containing signature => " );
		    String sigfile = b.readLine();

		    System.out.print( "File containing the cert. => " );
		    String infile = b.readLine();

		    String verified = verify( msgfile, sigfile, infile );
		    System.out.println( verified );
		}
		else if (choice.compareToIgnoreCase("q") == 0)
		{
		    System.exit(0);
		}
		else ;

		choice = "";
	    }
	}
	catch( Exception e )
	{
	    e.printStackTrace();
	}
    }


    /**
     * An implementation of the encrypt primitive which assumes that 
     * the algorithm to be used is RSA.
     *
     * @param infile a filename for a file which contains a PEM-encoded cert
     * @param mfile a filename for the file containing the message to encrypt
     * @param outfile a filename where to dump the result to
     * @return the base64 encoded ciphertext
     * @throws Exception if bad stuff happens
     */
    static public String encrypt( String infile, String mfile, String outfile )
	throws Exception
    {
	String msg = FileUtil.read( mfile );
	String certstr = KeyUtil.prettyPrintCerts( FileUtil.read(infile) );
	X509Certificate cert = KeyUtil.getCertificate( certstr );

	System.out.println( "\nEncrypting message: " + msg );

	Cipher c = Cipher.getInstance( "RSA" );
	c.init( Cipher.ENCRYPT_MODE, cert );
	
	BASE64Encoder b64 = new BASE64Encoder();
	String cipher64 = b64.encode( c.doFinal(msg.getBytes()) );
	
	FileUtil.write( outfile, cipher64 );

	return cipher64;
    }


    /**
     * An implementation of the decrypt operation assuming RSA keys.
     *
     * @param file the file containing the ciphertext
     * @param alias the keystore alias for the private key
     * @param b the reader pointing to STDIN
     * @return the plaintext
     * @throws Exception if bad stuff happens
     */
    static public String decrypt( String file, String alias, BufferedReader b )
	throws Exception
    {
	// Load the keystore
	System.out.print( "Keystore containing the priv key => " );
	String kf = b.readLine();

	System.out.print( "Keystore password => " );
	String pw = b.readLine();
	
	// Start the timer
	long start = System.currentTimeMillis();

	KeyStore ks = KeyStore.getInstance( "JKS" );
	ks.load( new FileInputStream(kf), pw.toCharArray() );

	// Get the ciphertext
	String cipher64 = FileUtil.read( file );
	BASE64Decoder b64 = new BASE64Decoder();
	byte [] encbytes = b64.decodeBuffer( cipher64 );

	// Get the private key and decrypt
	Key key = ks.getKey( alias, pw.toCharArray() );
	Cipher c = Cipher.getInstance( "RSA" );
	c.init( Cipher.DECRYPT_MODE, key );

	byte[] cleartext = c.doFinal( encbytes );

	// Finish timing
	long time = System.currentTimeMillis() - start;
		    
	if (TIMING)
	{
	    System.out.println( "Elapsed time: " + time + " ms." );
	}

	return new String( cleartext );
    }


    /**
     * An implementation of the signing operation using RSA keys.
     *
     * @param msgfile the filename containing the message to sign
     * @param outfile the filename to dump the signature to
     * @param alias the keystore alias for the private key
     * @param b the reader pointing to STDIN
     * @return the base64 encoded signature
     * @throws Exception if bad stuff happens
     */
    static public String sign( String msgfile, String outfile, String alias,
			       BufferedReader b ) throws Exception
    {
	// Load the keystore
	System.out.print( "Keystore containing the priv. key => " );
	String kf = b.readLine();

	System.out.print( "Keystore password => " );
	String pw = b.readLine();

	// Start timer
	long start = System.currentTimeMillis();

	KeyStore ks = KeyStore.getInstance( "JKS" );
	ks.load( new FileInputStream(kf), pw.toCharArray() );

	// Load the msg
	byte [] msg = FileUtil.readBytes( msgfile );
	
	// Get the key and sign
	KeyStore.PasswordProtection pp = 
	    new KeyStore.PasswordProtection( pw.toCharArray() );
	KeyStore.PrivateKeyEntry pke = 
	    (KeyStore.PrivateKeyEntry) ks.getEntry( alias, pp );

	PrivateKey privkey = pke.getPrivateKey();

	Signature s = Signature.getInstance( "SHA1withRSA" );
	s.initSign( privkey );
	s.update( msg );
	byte [] sig = s.sign();

        // Finish timing
	long time = System.currentTimeMillis() - start;
		    
	if (TIMING)
	{
	    System.out.println( "Elapsed time: " + time + " ms." );
	}

	// Write the bytes
	FileUtil.writeBytes( outfile, sig );
	
	BASE64Encoder b64 = new BASE64Encoder();
	return b64.encode( sig );
    }


    /**
     * An implementation of RSA verification.
     *
     * @param msgfile filename containing the plaintext message
     * @param sigfile filename containing the signature
     * @param crtfile filename containing the PEM encoded X509 cert
     * @return a String indicating whether the file verified or not
     * @throws Exception if bad stuff happens
     */
    static public String verify( String msgfile, String sigfile, 
				 String crtfile ) throws Exception
    {
	// Get the message
	byte [] msg = FileUtil.readBytes( msgfile );
	System.out.println( "\nThe message: " + new String(msg) );

	// Get the signature
	byte [] sig = FileUtil.readBytes( sigfile );
	BASE64Encoder b64 = new BASE64Encoder();
	System.out.println( "Signed message digest:\n" + b64.encode(sig) );

	// Get the cert
	String strcrt = KeyUtil.prettyPrintCerts( FileUtil.read( crtfile ) );
	X509Certificate crt = KeyUtil.getCertificate( strcrt );
	System.out.println( "The certificate:" );
	KeyUtil.dumpPC( crt );

	// Verify
	Signature s = Signature.getInstance( "SHA1withRSA" );
	s.initVerify( crt );
	s.update( msg );
	boolean verifies = s.verify( sig );

	return "\n\n---> Signature Verified: " + verifies;
    }
}
