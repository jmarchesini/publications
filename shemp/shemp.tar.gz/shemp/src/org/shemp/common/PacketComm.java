/* Copyright (c) 2004-2005, John Marchesini.  All rights reserved. */

package org.shemp.common;

import java.io.*;
import java.util.*;


/**
 * Helpers for sending and receiving packets.
 */
public class PacketComm
{
    /**
     * Public method used to send packets.
     *
     * @param pkt the packet to send
     * @param out the OutputStream to send it on
     */
    static public void send( Packet pkt, OutputStream out ) throws IOException
    {
	out.write( pkt.getBytes() );
	out.flush();
    }


    /**
     * Public method used to receive packets.
     *
     * @param in the InputStream to receive a packet from
     * @return packet
     */
    static public Packet recv( InputStream in ) throws IOException
    {
        // Read the header
	int headersize = Header.getHeaderSize();
	byte[] headbuf = new byte[headersize];
	in.read( headbuf, 0, headersize );
	Header header = new Header( headbuf );

	// Read the payload
	int payloadsize = header.getSize();
	byte [] paybuf = new byte[payloadsize];
	in.read( paybuf, 0, payloadsize );
	Packet pkt = new Packet( header, paybuf );

	return pkt;
    }


}
