#! /usr/bin/perl -w

$ENV{PATH} = "/sbin:/usr/sbin:/bin:/usr/bin:/usr/share/jdk1.5.0/bin:/usr/local/java/jdk1.5.0/bin:/usr/share/jre1.5.0/bin:/usr/java/jre1.5.0/bin";

#------------------------------------------------------------------------------#
use strict;

# Globals for the SHEMP system---these could come from a conf
# file if I weren't so lazy.

my $CERTDIR = "../certs";
my $TEMPDIR = "/tmp/";
my $REPDIR = "../repository";
my $SHUTILDIR = "../shutil";


#------------------------------------------------------------------------------#
# Helpers
#------------------------------------------------------------------------------#
sub getcn
{
    my $pem = shift;

    my $cn = "";
    my $dn = `openssl x509 -in $pem -noout -subject -nameopt RFC2253`;

    # Peel the CN out of the name
    if ($dn =~ m/(CN.*?,)/g)
    {
	$cn = $1;
	$cn =~ s/CN=//g;
	$cn =~ s/,//g;
    }

    return $cn;
}

#------------------------------------------------------------------------------#
sub confighelper
{
    my $config = shift;
    my $admin = shift;
    my $line;

    if (! -e $config)
    {
	die "Couldn't find openssl config at " . $config;
    }

    # We need to change the location from demoCA to where
    #  we are running from.  Also need these to have basicConstraints
    #  set to TRUE.

    open( INFILE, "< " . $config ) or die "Couldn't open " . $config;
    open( OUTFILE, "> " . $admin . "/" . $admin . ".cnf" );

    while ($line = <INFILE>)
    {
	$line =~ s/demoCA/$admin/g;
	$line =~ s/CA:FALSE/CA:TRUE/g;
	
	if ($admin eq "radmin")
	{
	    $line =~ s/cacert/radmincert/g;
	    $line =~ s/cakey/radminkey/g;
	}
	if ($admin eq "padmin")
	{
	    $line =~ s/cacert/padmincert/g;
	    $line =~ s/cakey/padminkey/g;
	}
	
	print OUTFILE $line;
    }

    close( INFILE );
    close( OUTFILE );
}

#------------------------------------------------------------------------------#
sub setupfiles
{
    my $dir = shift;

    # Set up the files and directories needed by openssl.
    mkdir $dir; 
    mkdir $dir . "/newcerts";
    mkdir $dir . "/private";

    my $index = "touch " . $dir . "/index.txt";
    system( $index );

    open(FILE, "> " . $dir . "/serial");
    print FILE "01";
    close(FILE);
}

#------------------------------------------------------------------------------#
sub mintidcerts
{
    my $caller = shift;

    my $box;
    my $admin;
    my $dir;

    if ($caller eq "radmin")
    {
	$box = "repository";
	$admin = "Repository Admin.";
	$dir = $REPDIR;
    }
    elsif ($caller eq "padmin")
    {
	$box = "platform";
	$admin = "Platform Admin.";
	$dir = $SHUTILDIR
    }

    print "\n---> Adding Root CA and ". $admin . " certificates to keystore.\n";
    print "File containing the root CA certificate? => ";
    my $cacert = <STDIN>;
    chop $cacert;

    if (! -e $cacert)
    {
	print "Couldn't find the CA certificate.  Aborting.\n";
	return;
    }

    # Import the Root CA cert into the machine keystore
    print "\n---> Importing Root CA into " . $box . " keystore.\n";
    my $rootname = getcn( $cacert );
    my $imp = "keytool -import -alias \"". $rootname . "\" -file " . $cacert;
    $imp .= " -keystore " . $dir . "/keys/keystore";
    system( $imp );

    if ($caller eq "radmin")
    {
	# Import the Root CA cert into the user keystore
	print "\n---> Importing Root CA into user keystore.\n";
	my $imp2 = "keytool -import -alias \"". $rootname . "\" -file ";
	$imp2 .= $cacert . " -keystore " . $dir . "/keys/userstore";
	system( $imp2 );
    }

    # Import the admin's cert.
    my $racert = $caller . "/" . $caller ."cert.pem";

    if (! -e $racert)
    {
	print "Couldn't find the " . $admin ."'s certificate.\n";
	print "Looked in " . $racert . ".  Aborting.\n";
	return;
    }

    print "\n---> Importing certificate for the " . $admin . "\n";
    my $raname = getcn( $racert );
    my $imp3 = "keytool -import -alias \"". $raname . "\" -file " . $racert;
    $imp3 .= " -keystore " . $dir . "/keys/keystore";
    system( $imp3 );

    # Generate a keypair for the box
    print "\n---> Generating a keypair for the " . $box . ".\n";
    print "Unique Common Name (CN) for the " . $box . "? => ";
    my $boxname = <STDIN>;
    chop $boxname;

    my $gen = "keytool -genkey -alias \"" . $boxname . "\" -keyalg RSA ";
    $gen .= "-validity 365 -keysize 2048 -keystore " . $dir;
    $gen .= "/keys/keystore";
    system( $gen );

    # Generate CSR
    print "\n---> Generating CSR for the new keypair.\n";
    my $csr = "keytool -certreq -alias \"" . $boxname . "\" -file requests/";
    $csr .= $boxname . "req.pem -keystore " . $dir . "/keys/keystore";
    system( $csr );

    my $certfile = $CERTDIR . "/" . $boxname . "cert.pem";

    # Get the admin to sign the csr
    print "\n---> Signing the new CSR.\n";
    my $sign = "openssl ca -in requests/" . $boxname . "req.pem ";
    $sign .= "-out " . $certfile;
    $sign .= " -config " . $caller . "/" . $caller . ".cnf ";
    $sign .= "-policy policy_anything -notext";
    system( $sign );

    print "\nWrote the signed certificate to " . $certfile;

    # Importing the signed cert.
    print "\n\n---> Importing the signed certificate.\n";
    my $addcert = "keytool -import -alias \"" . $boxname . "\" -file ";
    $addcert .= $certfile . " -keystore " . $dir . "/keys/keystore";
    system( $addcert );

    # This is the CN
    return $boxname;
}

#------------------------------------------------------------------------------#
sub signattrcert
{
    my $box = shift;
    my $boxname = shift;

    my $envfile = $TEMPDIR . "envelope";
    my $digfile = $TEMPDIR . "digest";
    my $admin = "ca";

    my $line;
    my $cert;
    my $digest;
    my $envelope;

    if ($box =~ m/platform/i)
    {
	$admin = "padmin";
    }
    elsif ($box =~ m/repository/i)
    {
	$admin = "radmin";
    }

    my $subjectcert = $CERTDIR . "/" . $boxname . "cert.pem";
    my $issuercert =  $admin . "/" . $admin . "cert.pem";
    my $unsignedcert = $TEMPDIR . $boxname . "unsig.xml";

    if ($box eq "KUP")
    {
	print "\n---> Generating and signing the KUP for " . $boxname . ".\n";
	my $cmd = "../tools/kupbuilder $subjectcert $issuercert $unsignedcert";
	system( $cmd );
    }
    else
    {
	print "\n---> Generating a new " . $box . " attribute certificate.\n";
	my $cmd = "../tools/acbuilder $subjectcert $issuercert $unsignedcert";
	system( $cmd );
    }

    # Read the attr cert
    open( INFILE, "<" . $unsignedcert ) or die "Couldn't open " . $unsignedcert;

    while ($line = <INFILE>)
    {
	$cert .= $line;
    }

    close( INFILE );

    # Strip whitespace
    my $temp = $cert;
    $temp =~ s/\s//g;
    
    # Strip XML comments
    $temp =~ s/(<!--).*?(-->)//g;
    
    # Extract the envelope and drop in a file
    if ($temp =~ m/(<envelope>.*<\/envelope>)/g)
    {
	$envelope = $1;
    }

    open( TEMPFILE, ">" . $envfile );
    print TEMPFILE $envelope;
    close( TEMPFILE );
    
    # SHA1(envelope) and sign with the appropriate key.
    my $command = "openssl dgst -sha1 -hex -out " . $digfile . " -sign ";
    $command .= $admin . "/private/" . $admin . "key.pem " . $envfile;
    system( $command );

    # Read the digest out
    open( DIGFILE, "< " . $digfile ) or die "Couldn't open " . $digfile;

    while ($line = <DIGFILE>)
    {
	$digest .= $line;
    }

    close( DIGFILE );

    # Clean up the digest---ditch "SHA1(file)= ".
    chop $digest;
    $digest =~ s/(SHA1).*?(= )//g;

    # Stuff signed digest into the cert
    $cert =~ s/<envelopeSignature>.*<\/envelopeSignature>/<envelopeSignature>$digest<\/envelopeSignature>/g;

    # Put signed cert back to a file
    my $certfile = $CERTDIR . "/" . $boxname . "attr.xml";

    open( SIGNED, ">" . $certfile );
    print SIGNED $cert;
    close( SIGNED );

    print "\nWrote the signed attribute certificate to " . $certfile;

    # Clean up
    unlink( $envfile );
    unlink( $digfile );
    unlink( $unsignedcert );
}


#------------------------------------------------------------------------------#
# RA functions
#------------------------------------------------------------------------------#
sub genracert
{
    my $dir = "radmin";

    if (-e $dir)
    {
	print "\nThe directory '" . $dir . "' already exists.\n";
	print "Overwriting this directory will create a new Rep. Admin. key.\n";
	print "Are you sure you really want to do this?\n\n";
	print "[y/n] => ";

	my $arg = <STDIN>;
	chop $arg;

	if ($arg !~ m/y/i)
	{
	    return;
	}
    }

    print "\nBuilding directory structure for Rep. Admin. . .";

    my $reqdir = "requests";
    if (! -e $reqdir)
    {
	mkdir $reqdir;
    }

    setupfiles( $dir );
    print "Done.\n";

    print "Copying config file for the Rep. Admin. . .";
    confighelper("/etc/ssl/openssl.cnf", "radmin");
    print "Done.\n";

    print "\nGenerating a new Rep. Admin. keypair and certificate request.\n";
    my $keyfile = $dir . "/private/radminkey.pem";
    my $reqfile = $reqdir . "/radminreq.pem";
    my $commandline = "openssl genrsa -out ". $keyfile . " 2048";
    system( $commandline );

    my $request = "openssl req -new -key " . $keyfile . " -out " . $reqfile;
    system( $request );

    return;
}

#------------------------------------------------------------------------------#
sub addrep
{
    # Set up the id certs.
    my $cn = mintidcerts( "radmin" );

    # Set up the attr certs.
    signattrcert( "repository", $cn );
}

#------------------------------------------------------------------------------#
sub genuser
{
    my $digfile = $TEMPDIR . "digest";
    my $digest;
    my $line;

    # Generate a keypair for the user
    print "\n---> Generating a keypair for a new SHEMP user.\n";
    print "Unique login name for this user => ";
    my $uname = <STDIN>;
    chop $uname;

    my $gen = "keytool -genkey -alias \"" . $uname . "\" -keyalg RSA -validity";
    $gen .= " 365 -keysize 2048 -keystore " . $REPDIR . "/keys/userstore";
    system( $gen );

    # Generate CSR
    print "\n---> Generating CSR for the new keypair.\n";
    my $csr = "keytool -certreq -alias \"" . $uname . "\" -file requests/";
    $csr .= $uname . "req.pem -keystore " . $REPDIR . "/keys/userstore";
    system( $csr );

    # Generate a repository account for the user
    print "\n---> Creating a new account on the repository with login: ";
    print $uname . "\n";

    print "Password for " . $uname . " => ";
    my $pass = <STDIN>;
    chop $pass;

    # SHA1(envelope) and sign with the appropriate key.
    my $command = "openssl dgst -sha1 -hex -out " . $digfile;
    system( "echo -n $pass | $command" );

    # Read the digest out
    open( DIGFILE, "< " . $digfile ) or die "Couldn't open " . $digfile;

    while ($line = <DIGFILE>)
    {
	$digest .= $line;
    }

    close( DIGFILE );

    # Clean up the digest
    chop $digest;
    my $acctline = $uname . "::" . $digest . "\n";

    open( LOGIN, ">>" . $REPDIR . "/etc/passwd" );
    print LOGIN $acctline;
    close( LOGIN );

    # Clean up
    unlink( $digfile );

    print "\n---> The request was placed in requests/" . $uname . "req.pem\n";
    print "and needs to be signed by the CA.  After that, you can import the\n";
    print "signed certificate into the repository.\n";

}

#------------------------------------------------------------------------------#
sub importuser
{
    my $uname;

    # Importing the signed cert.
    print "\n---> Importing the signed certificate.";
    print "\nUnique login name for the user => ";
    $uname = <STDIN>;
    chop $uname;

    my $addcert = "keytool -import -alias \"" . $uname . "\" -file ";
    $addcert .= $CERTDIR . "/" . $uname . "cert.pem";
    $addcert .= " -keystore " . $REPDIR . "/keys/userstore";
    system( $addcert );
}


#------------------------------------------------------------------------------#
# CA functions
#------------------------------------------------------------------------------#
sub gencacert
{
    my $dir = "ca";

    if (-e $dir)
    {
	print "\nThe directory '" . $dir . "' already exists.\n";
	print "Overwriting this directory will create a new CA key.\n";
	print "Are you sure you really want to do this?\n\n";
	print "[y/n] => ";

	my $arg = <STDIN>;
	chop $arg;

	if ($arg !~ m/y/i)
	{
	    return;
	}
    }

    print "\nBuilding directory structure for CA. . .";
    setupfiles( $dir );
    print "Done.\n";
    
    print "Copying config file for the CA. . .";
    confighelper("/etc/ssl/openssl.cnf", "ca");
    print "Done.\n";

    print "\nGenerating a new self-signed root CA certificate.\n";
    my $keyfile = $dir . "/private/cakey.pem";
    my $certfile = $dir . "/cacert.pem";

    my $commandline = "openssl req -x509 -newkey rsa:2048 -keyout ";
    $commandline .= $keyfile . " -out " . $certfile;
    system( $commandline );

    my $rootname = getcn( $certfile );
    my $outfile = $CERTDIR . "/" . $rootname . "cert.pem";
    system( "cp $certfile $outfile" );

    print "\nWrote the self-signed CA certificate to " . $outfile;
	
    return;
}

#------------------------------------------------------------------------------#
sub certifyadmin
{
    my $arg = "z";
    my $requestor;

    while ($arg !~ m/r|p|q/i)
    {
	print "\nWould you like to certify the \n";
	print "(R)epository admin\n";
	print "(P)latform admin\n";
	print "(Q)uit and return to the main menu\n";
	print "\n[r/p/q] => ";

	$arg = <STDIN>;
	chop $arg;

      SWITCH:
	{
	    if ($arg =~ m/r/i) { $requestor = "radmin"; last SWITCH };
	    if ($arg =~ m/p/i) { $requestor = "padmin"; last SWITCH };
	    if ($arg =~ m/q/i) { return };
	    $arg = "z";
	}
    }

    my $outfile = $requestor . "/" . $requestor . "cert.pem";

    my $commandline = "openssl ca -in requests/" . $requestor ."req.pem ";
    $commandline .= "-out " . $outfile;
    $commandline .= " -config ca/ca.cnf -policy policy_anything -notext";
    system( $commandline );

    my $cn = getcn( $outfile );
    my $certfile = $CERTDIR . "/" . $cn . "cert.pem";
    system( "cp $outfile $certfile" );

    print "\nA copy of the certificate was placed in " . $certfile;
}

#------------------------------------------------------------------------------#
sub certifyuser
{
    my $req;

    print "\n---> Certifying a keypair for a new SHEMP user.\n";
    print "Unique login name for the user => ";
    $req = <STDIN>;
    chop $req;

    my $certfile = $CERTDIR . "/" . $req . "cert.pem";

    my $commandline = "openssl ca -in requests/" . $req . "req.pem ";
    $commandline .= "-out " . $certfile;
    $commandline .= " -config ca/ca.cnf -policy policy_anything -notext";
    system( $commandline );

    print "\n---> The signed certificate has been created in\n";
    print $certfile . " and needs to be imported\n";
    print "into the repository's keystore by the Repository Admin.\n";

    # Get the KUP signed.
    signattrcert( "KUP", $req );    
}


#------------------------------------------------------------------------------#
# PA Functions
#------------------------------------------------------------------------------#
sub genpacert
{
    my $dir = "padmin";

    if (-e $dir)
    {
	print "\nThe directory '" . $dir . "' already exists.\n";
	print "Overwriting this directory will create a new Pla. Admin. key.\n";
	print "Are you sure you really want to do this?\n\n";
	print "[y/n] => ";

	my $arg = <STDIN>;
	chop $arg;

	if ($arg !~ m/y/i)
	{
	    return;
	}
    }

    print "\nBuilding directory structure for Platform Admin. . .";

    my $reqdir = "requests";

    if (! -e $reqdir)
    {
	mkdir $reqdir;
    }

    setupfiles( $dir );
    print "Done.\n";

    print "Copying config file for the Platform Admin. . .";
    confighelper("/etc/ssl/openssl.cnf", "padmin");
    print "Done.\n";

    print "\nGenerating a new Pla. Admin. keypair and certificate request.\n";

    my $keyfile = $dir . "/private/padminkey.pem";
    my $reqfile = $reqdir . "/padminreq.pem";
    my $commandline = "openssl genrsa -out ". $keyfile . " 2048";
    system( $commandline );

    my $request = "openssl req -new -key " . $keyfile . " -out " . $reqfile;
    system( $request );
	
    return;
}

#------------------------------------------------------------------------------#
sub addplatform
{
    # Set up the id certs.
    my $cn = mintidcerts( "padmin" );

    # Set up the attr certs.
    signattrcert( "platform", $cn );
}


#------------------------------------------------------------------------------#
# Menu functions
#------------------------------------------------------------------------------#
sub plaadmin
{
    my $arg = "z";

    while ($arg !~ m/g|a|r/i)
    {
	print "\n\nSHEMP Platform Administrator Operations:\n";
	print "---------------------------------------\n\n";
	print "G)enerate a Plat. Admin keypair and certificate request\n";
	print "A)dd a new platform\n";
	print "R)eturn to the main menu\n";
	print "\n[g/a/r] => ";

	$arg = <STDIN>;
	chop $arg;

      SWITCH:
	{
	    if ($arg =~ m/g/i) { genpacert(); last SWITCH };
	    if ($arg =~ m/a/i) { addplatform(); last SWITCH };
	    if ($arg =~ m/r/i) { return };
	}

	$arg = "z";
    }
}

#------------------------------------------------------------------------------#
sub repadmin
{
    my $arg = "z";

    while ($arg !~ m/g|a|u|r|i/i)
    {
	print "\n\nSHEMP Repository Administrator Operations:\n";
	print "-----------------------------------------\n\n";
	print "G)enerate a Rep. Admin keypair and certificate request\n";
	print "A)dd a new repository\n";
	print "Generate new (u)ser keypair, certificate request, and account\n";
	print "I)mport a CA-signed user certificate into the repository\n";
	print "R)eturn to the main menu\n";
	print "\n[g/a/u/i/r] => ";

	$arg = <STDIN>;
	chop $arg;

      SWITCH:
	{
	    if ($arg =~ m/g/i) { genracert(); last SWITCH };
	    if ($arg =~ m/a/i) { addrep(); last SWITCH };
	    if ($arg =~ m/u/i) { genuser(); last SWITCH };
	    if ($arg =~ m/i/i) { importuser(); last SWITCH };
	    if ($arg =~ m/r/i) { return };
	}

	$arg = "z";
    }
}

#------------------------------------------------------------------------------#
sub certauth
{
    my $arg = "z";

    while ($arg !~ m/g|a|u|r/i)
    {
	print "\n\nSHEMP Certificate Authority Operations:\n";
	print "--------------------------------------\n\n";
	print "G)enerate a new self-signed CA certificate\n";
	print "Certify a new (a)dministrator\n";
	print "Certify a new (u)ser\n";
	print "R)eturn to the main menu\n";
	print "\n[g/a/u/r] => ";

	$arg = <STDIN>;
	chop $arg;

      SWITCH:
	{
	    if ($arg =~ m/g/i) { gencacert(); last SWITCH };
	    if ($arg =~ m/a/i) { certifyadmin(); last SWITCH };
	    if ($arg =~ m/u/i) { certifyuser(); last SWITCH };
	    if ($arg =~ m/r/i) { return };
	}

	$arg = "z";
    }
}

#------------------------------------------------------------------------------#
main:
{
    my $arg = "z";

    while ($arg !~ m/c|r|p|q/i)
    {
	system("clear");

	print "============================================\n";
	print "* Welcome to the SHEMP admin utility v0.1. *\n";
	print "============================================\n\n";
	print "What set of operations would you like?\n\n";
	print "C)ertificate Authority\n";
	print "R)epository Administrator\n";
	print "P)latform Administrator\n";
	print "Q)uit\n";
	print "\n[c/r/p/q] => ";

	$arg = <STDIN>;
	chop $arg;

      SWITCH:
	{
	    if ($arg =~ m/c/i) { certauth(); last SWITCH };
	    if ($arg =~ m/r/i) { repadmin(); last SWITCH };
	    if ($arg =~ m/p/i) { plaadmin(); last SWITCH };
	    if ($arg =~ m/q/i) { exit(0) };
	}

	$arg = "z";
    }
}
                                                                                
                                                                                
#------------------------------------------------------------------------------#
# EOF
