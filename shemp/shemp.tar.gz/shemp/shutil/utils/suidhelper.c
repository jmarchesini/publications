#include <unistd.h>

int main( int argc, char *argv[] )
{
    setuid( 0 );
    seteuid( 0 );
    system( argv[1] );

    return 0;
}
