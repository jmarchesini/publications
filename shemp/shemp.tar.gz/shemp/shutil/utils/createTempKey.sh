#!/bin/bash

#-------------------------------------------------------------------------
# This is the place where you put the command that Shapi will use to
# generate a new keypair.  Sometimes, you may need to run the key
# generator as 'root' (i.e., if you use IBM's TPM driver to generate a
# TPM key).  So, the program 'suidhelper' will execute whatever it's given
# at setuid root.  Of course, this is highly dangerous---if you tell it to
# 'cd / ; rm -rf *' you're hosed.
#
# This file system polymorphism isn't really that great, but it's flexible
# and allows platform admins to use a number of different client key
# mechanisms without having to recompile.
#
# Some examples:
# /home/carlo/sandbox/exe/suidhelper './tcpa_demo > temp'
# openssl genrsa -out temp 2048

### For TPM Keys -- signing proxy example
# cd ./utils
# ./suidhelper './createkey 0x40000000 tnd0007 tempkey doodoo'
# sleep 5s
# ./suidhelper './loadkey 0x40000000 tnd0007 tempkey'
##########################################################################


### For Java Keys -- encryption proxy example
cd ./utils

keytool -genkey -alias tempkey -keyalg RSA -validity 1 -keysize 2048 -keystore tempstore -dname "CN=TEMP, OU=TEMP, O=TEMP, L=TEMP, C=TEMP" -storepass doodoo -keypass doodoo 

keytool -export -alias tempkey -keystore tempstore -rfc -file tempkey.cer -storepass doodoo -keypass doodoo

cd ../../tools
./extractkey ../shutil/utils/tempkey.cer ../shutil/utils/tempkey.pem
###########################################################################
