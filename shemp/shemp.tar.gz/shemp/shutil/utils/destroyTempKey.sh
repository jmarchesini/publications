#!/bin/bash

#-------------------------------------------------------------------------
# This is the place where you put the command that Shapi will use to
# destroy a keypair.  Sometimes, you may need to run the key
# destructor as 'root' (i.e., if you use IBM's TPM driver to generate a
# TPM key).  So, the program 'suidhelper' will execute whatever it's given
# at setuid root.  Of course, this is highly dangerous---if you tell it to
# 'cd / ; rm -rf *' you're hosed.
#
# This file system polymorphism isn't really that great, but it's flexible
# and allows platform admins to use a number of different client key
# mechanisms without having to recompile.
#
# Some examples:
# /home/carlo/sandbox/exe/suidhelper './evictkey 0x5def43 '
# openssl genrsa -out temp 2048

cd ./utils

### Clean up the TPM keys
# ./suidhelper './evictkey all'

### Clean up the keystore
rm tempstore

rm tempkey.*
